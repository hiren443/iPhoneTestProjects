//
//  MyFriendsViewController.h
//  MyFriends
//
//  Created by Asif Amjad on 8/16/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FBConnect.h"

@interface MyFriendsViewController : UIViewController<UITableViewDataSource, UITableViewDelegate,FBSessionDelegate,FBRequestDelegate, FBDialogDelegate> {
    IBOutlet UITableView *tblMain;
    
    Facebook *facebook;
    NSMutableArray *arrData; 
    IBOutlet UIButton *btnFrends;
}

@property (nonatomic, retain) Facebook * facebook;
-(IBAction) btnGetFriends:(id)sender;
-(IBAction) logout;
@end
