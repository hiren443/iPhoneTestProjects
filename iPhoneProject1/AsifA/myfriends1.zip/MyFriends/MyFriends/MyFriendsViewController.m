//
//  MyFriendsViewController.m
//  MyFriends
//
//  Created by Asif Amjad on 8/16/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MyFriendsViewController.h"
#import "MyFriendsAppDelegate.h"

#define APP_ID @"145062165564860"

@implementation MyFriendsViewController
@synthesize facebook;
- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (arrData) {
        return [arrData count];
    }
    return 0;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
	static NSString *CellIdentifier = @"CellAccounts";//[NSString stringWithFormat:@"CellAccounts", indexPath.section,indexPath.row, index];
	
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    
    NSDictionary* object = [arrData objectAtIndex:indexPath.row];
    
    cell.textLabel.text = [object objectForKey:@"name"];
    
    return cell;
}

#pragma mark -


#pragma mark facebook methods
-(IBAction)btnGetFriends:(id)sender;{
    
    if (!facebook) {
        facebook = [[Facebook alloc] initWithAppId:APP_ID];
    }
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"FBAccessTokenKey"] 
        && [defaults objectForKey:@"FBExpirationDateKey"]) {
        facebook.accessToken = [defaults objectForKey:@"FBAccessTokenKey"];
        facebook.expirationDate = [defaults objectForKey:@"FBExpirationDateKey"];
    }
    
    
    //CompadreAppDelegate
    MyFriendsAppDelegate *appdeleget = (MyFriendsAppDelegate *)[[UIApplication sharedApplication] delegate];
    appdeleget.facebook = facebook;
    //[facebook dialog:@"yess" andDelegate:self];
    if (![facebook isSessionValid]) {
        NSArray *_permissions = [NSArray arrayWithObjects:
                                 @"read_stream", @"email", @"user_birthday",nil];
        
         [facebook authorize:_permissions delegate:self];
    }else{
        [facebook requestWithGraphPath:@"me/friends" andDelegate:self];
    }
}
- (void)dialogDidComplete:(FBDialog *)dialog;{

}
- (void)fbDidLogin {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:[facebook accessToken] forKey:@"FBAccessTokenKey"];
    [defaults setObject:[facebook expirationDate] forKey:@"FBExpirationDateKey"];
    [defaults synchronize];
    [facebook requestWithGraphPath:@"me/friends" andDelegate:self];
}
- (void)fbDidNotLogin:(BOOL)cancelled;{
    NSLog(@"did not loged in");
}
- (void)request:(FBRequest *)request didReceiveResponse:(NSURLResponse *)response;{
    NSLog(@"response received");
}
- (void)request:(FBRequest *)request didLoad:(id)result {
    //NSLog(@"%@",result);
    NSDictionary *dic = (NSDictionary *)result;
    
    id data = [dic objectForKey:@"data"];
    if (data) {
        if (arrData) {
            [arrData release],arrData = nil;
        }
        arrData = [[NSMutableArray alloc] initWithArray:data];
        [tblMain reloadData];
        
        NSLog(@"%@",data);
        
        btnFrends.hidden = YES;
    }
    
    
}

- (void)request:(FBRequest *)request didFailWithError:(NSError *)error {
    
}
#pragma mark -

#pragma mark - View lifecycle

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


-(IBAction) logout{
    [facebook logout:self];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:@"FBAccessTokenKey"];
    [defaults removeObjectForKey:@"FBExpirationDateKey"];
    [defaults synchronize];
}



@end
