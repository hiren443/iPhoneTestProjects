//
//  FriendList.h
//  abc
//
//  Created by openxcell123 technolabs on 8/24/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "abcAppDelegate.h"

@interface FriendList : UITableViewController{
    abcAppDelegate *obj;
}
@end
