//
//  MyFriendsAppDelegate.h
//  MyFriends
//
//  Created by Janis Pagal on 8/24/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import <UIKit/UIKit.h>
#import "MyFriendsViewController.h"

@interface MyFriendsAppDelegate : NSObject <UIApplicationDelegate> {
  UIWindow *window;
  MyFriendsViewController* controller;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

