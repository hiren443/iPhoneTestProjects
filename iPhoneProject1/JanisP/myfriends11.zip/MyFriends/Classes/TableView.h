//
//  TableView.h
//  MyFriends
//
//  Created by Janis Pagal on 8/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TableView : UITableViewController {
    NSMutableArray *friendsList;
}

@property (nonatomic,retain) NSMutableArray *friendsList;


@end
