//
//  MyFriendsAppDelegate.m
//  MyFriends
//
//  Created by Janis Pagal on 8/24/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MyFriendsAppDelegate.h"
#import "MyFriendsViewController.h"

@implementation MyFriendsAppDelegate

@synthesize window;


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
  // Override point for customization after application launch
  controller = [[MyFriendsViewController alloc] init];
  controller.view.frame = CGRectMake(0, 20, 320, 460);
  [window addSubview:controller.view];

  [window makeKeyAndVisible];
  return YES;

}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url {
  return [[controller facebook] handleOpenURL:url];
}

- (void)dealloc {
  [window release];
  [controller release];
  [super dealloc];
}


@end
