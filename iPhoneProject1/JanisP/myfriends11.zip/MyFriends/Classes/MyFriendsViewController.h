//
//  MyFriendsViewController.h
//  MyFriends
//
//  Created by Janis Pagal on 8/24/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import <UIKit/UIKit.h>
#import "FBConnect.h"
#import "TableView.h"


@interface MyFriendsViewController : UIViewController
<FBRequestDelegate,
FBDialogDelegate,
FBSessionDelegate>{
  IBOutlet UILabel* _label;
  IBOutlet UIButton* _getUserInfoButton;
  Facebook* _facebook;
  NSArray* _permissions;
    
    
    UITableView *_tblView;
    
    NSMutableArray *friendsList;
}

@property (nonatomic, retain) IBOutlet UITableView *tblView;
@property(nonatomic, retain) UILabel* label;

@property (nonatomic, retain
           ) NSMutableArray *friendsList;

@property(readonly) Facebook *facebook;


-(IBAction)getUserInfo:(id)sender;

@end
