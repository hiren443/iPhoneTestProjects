//
//  MyFriendsViewController.m
//  MyFriends
//
//  Created by Janis Pagal on 8/24/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MyFriendsViewController.h"
#import "FBConnect.h"

static NSString* kAppId = @"159568340789244";

@implementation MyFriendsViewController
@synthesize tblView = _tblView;

@synthesize label = _label, facebook = _facebook;
@synthesize friendsList;



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
  if (!kAppId) {
    NSLog(@"missing app id!");
    exit(1);
    return nil;
  }


  if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
    _permissions =  [[NSArray arrayWithObjects:
                      @"read_stream", @"publish_stream", @"offline_access",nil] retain];
    _facebook = [[Facebook alloc] initWithAppId:kAppId
                                    andDelegate:self];
  }

  return self;
}


- (void)viewDidLoad {
    [self.label setText:@" "];
    _getUserInfoButton.hidden = NO;
    _tblView.hidden = YES;
}


- (void)dealloc {
    [_label release];
    [_getUserInfoButton release];
    [_facebook release];
    [_permissions release];
    [_tblView release];
    [super dealloc];
}



- (IBAction)getUserInfo:(id)sender {
    [_facebook authorize:_permissions];
}



// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
  return YES;
}


- (void)fbDidLogin {
    [self.label setText:@"Loading..."];
    _getUserInfoButton.hidden = NO;    
    [_facebook requestWithGraphPath:@"me/friends" andDelegate:self];
}


-(void)fbDidNotLogin:(BOOL)cancelled {
  NSLog(@"did not login");
}


- (void)fbDidLogout {
  [self.label setText:@" "];
  _getUserInfoButton.hidden    = YES;
}



- (void)request:(FBRequest *)request didReceiveResponse:(NSURLResponse *)response {
  NSLog(@"received response");
}


- (void)request:(FBRequest *)request didLoad:(id)result {
    if ([result isKindOfClass:[NSArray class]]) {
        result = [result objectAtIndex:0];
    }
      
    friendsList = [[NSMutableArray alloc] initWithObjects:[result objectForKey:@"name"], nil ];
    _tblView.hidden = NO;
    
    result=[result objectForKey:@"data"];
    
    NSSortDescriptor *sortDescriptor;
    sortDescriptor = [[[NSSortDescriptor alloc] initWithKey:@"name"
                                                  ascending:YES] autorelease];
    NSArray *sortDescriptors = [NSArray arrayWithObject:sortDescriptor];
    result = [result sortedArrayUsingDescriptors:sortDescriptors];

    for(int i=0;i<[result count];i++){
        NSDictionary *result2=[result objectAtIndex:i];
        NSString *result1=[result2 objectForKey:@"name"];
        NSLog(@"uid:%@",result1);
        [friendsList addObject:[NSString stringWithFormat:result1]];
    }
        
    TableView *vwFirst = [[TableView alloc] init];
    
    //friendsList = [[NSMutableArray alloc] initWithObjects:[result objectForKey:@"name"], nil ];
    //friendsList = dmvwController.friendsList  ;
    
    vwFirst.friendsList = self.friendsList;
    //[vwFirst setfriendsList:self.friendsList];
    
    
    [self presentModalViewController:vwFirst animated:YES ];
    
};


- (void)request:(FBRequest *)request didFailWithError:(NSError *)error {
  [self.label setText:[error localizedDescription]];
};



- (void)viewDidUnload {
    [self setTblView:nil];
    [super viewDidUnload];
}




@end
