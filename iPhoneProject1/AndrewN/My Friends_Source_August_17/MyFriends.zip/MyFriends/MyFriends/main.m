//
//  main.m
//  MyFriends
//
//  Created by The Linh NGUYEN on 8/17/11.
//  Copyright 2011 Nikmesoft Co. Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
