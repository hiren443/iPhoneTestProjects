//
//  GlobalVariables.h
//  MyFriends
//
//  Created by The Linh NGUYEN on 8/17/11.
//  Copyright 2011 Hirevietnamese Co. Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

#define APP_NAME @"My Friends"

// Facebook API
#define FB_API_KEY @"145062165564860"
#define FB_SECRET_KEY @"09d5ff4260a342ea3012cf2888e47d4e"

@interface GlobalVariables : NSObject {
    
}

@end
