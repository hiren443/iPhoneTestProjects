//
//  RootViewController.h
//  My Friends
//
//  Created by asif on 8/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FBConnect.h"
#import "FbGraph.h"
#import "FriendListController.h"

@interface RootViewController : UIViewController<FBRequestDelegate,FBDialogDelegate,FBSessionDelegate> {
	
	IBOutlet UILabel *appTitle;
	IBOutlet UIButton *btnViewFriends;
	

	Facebook * facebook;
	FbGraph *fbGraph;
    FriendListController *frndListView;
	NSArray* permissions;

}

@property (retain,nonatomic) IBOutlet UILabel *appTitle;
@property (retain,nonatomic) IBOutlet UIButton *btnViewFriends;

@property (retain,nonatomic) Facebook * facebook;
@property (retain,nonatomic) FbGraph * fbGraph;
@property (retain,nonatomic) NSArray* permissions;
@property (retain,nonatomic) FriendListController *frndListView;

-(IBAction) btnViewFriendsClicked:(id)sender;
@end
