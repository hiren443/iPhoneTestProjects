//
//  RootViewController.m
//  My Friends
//
//  Created by asif on 8/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "RootViewController.h"


static NSString* kAppId = @"145062165564860";

@implementation RootViewController

@synthesize appTitle,btnViewFriends,facebook,fbGraph,permissions,frndListView;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {

	
	if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
		
	}
    return self;
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
    
	if (!kAppId) {
		NSLog(@"missing app id!");
	}
	
    permissions =  [[NSArray arrayWithObjects:
                     @"friends_checkins", @"publish_stream", @"user_checkins", @"offline_access",nil] retain];
    facebook = [[Facebook alloc] initWithAppId:kAppId
                                   andDelegate:self];
    
    fbGraph = [[FbGraph alloc] initWithFbClientID:@"216349398385852"];
	

}

#pragma mark -
#pragma mark FbGraph Callback Function
/**
 * This function is called by FbGraph after it's finished the authentication process
 **/
- (void)fbGraphCallback:(id)sender {
	
	if ( (fbGraph.accessToken == nil) || ([fbGraph.accessToken length] == 0) ) {
		
		NSLog(@"You pressed the 'cancel' or 'Dont Allow' button, you are NOT logged into Facebook...I require you to be logged in & approve access before you can do anything useful....");
		
		//restart the authentication process.....
		[fbGraph authenticateUserWithCallbackObject:self andSelector:@selector(fbGraphCallback:) 
							 andExtendedPermissions:@"user_photos,user_videos,publish_stream,offline_access,user_checkins,friends_checkins"];
		
	} else {

		FbGraphResponse *fb_graph_response = [fbGraph doGraphGet:@"me/friends" withGetVars:nil];
		//NSLog(@"getMeButtonPressed:  %@", fb_graph_response.htmlResponse);
		NSString *data = [NSString stringWithFormat:@"%@",fb_graph_response.htmlResponse];
		
        if ([[data JSONValue] isKindOfClass:[NSDictionary class]]) {
			NSDictionary *dict = (NSDictionary*)[data JSONValue];
            frndListView = [[FriendListController alloc] initWithNibName:@"FriendListController" bundle:nil];
            
            frndListView.frndDataList = [dict objectForKey:@"data"];

            frndListView.frndDataList = [frndListView.frndDataList sortedArrayUsingDescriptors:[NSArray arrayWithObject:[[[NSSortDescriptor alloc] initWithKey:@"name" ascending:YES] autorelease]]];
	        [self.view addSubview:frndListView.view];
            //[friendListView release];
            
		}
		NSLog(@"------------>CONGRATULATIONS<------------, You're logged into Facebook...  Your oAuth token is:  %@", fbGraph.accessToken);
		
	}
	
}


-(IBAction) btnViewFriendsClicked:(id)sender{
	
	
	[fbGraph authenticateUserWithCallbackObject:self andSelector:@selector(fbGraphCallback:) 
						 andExtendedPermissions:@"user_photos,user_videos,publish_stream,offline_access,user_checkins,friends_checkins"];
	
	
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    
    [permissions release];

	[facebook release];
	[fbGraph release];
	[appTitle release];
	[btnViewFriends release];
    [frndListView release];
    [super dealloc];
}


@end
