//
//  FriendListController.h
//  My Friends
//
//  Created by Farhan Sh on 8/28/11.
//  Copyright 2011 Hirasoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FriendListController : UIViewController {
    
    IBOutlet UITableView *friendlistTableView;
    IBOutlet UILabel  * lblView;
    NSArray *frndDataList;
}
@property (retain,nonatomic) NSArray *frndDataList;
@property (retain,nonatomic) IBOutlet UILabel *lblView;
@end
