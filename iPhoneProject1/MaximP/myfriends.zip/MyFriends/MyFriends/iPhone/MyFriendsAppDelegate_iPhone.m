//
//  MyFriendsAppDelegate_iPhone.m
//  MyFriends
//
//  Created by Maxim Pervushin on 8/16/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MyFriendsAppDelegate_iPhone.h"

@implementation MyFriendsAppDelegate_iPhone

@end
