//
//  MyFriendsAppDelegate_iPad.m
//  MyFriends
//
//  Created by Maxim Pervushin on 8/16/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MyFriendsAppDelegate_iPad.h"

@implementation MyFriendsAppDelegate_iPad

@end
