//
//  MyFriendsAppDelegate_iPad.h
//  MyFriends
//
//  Created by Maxim Pervushin on 8/16/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MyFriendsAppDelegate.h"

@interface MyFriendsAppDelegate_iPad : MyFriendsAppDelegate

@end
