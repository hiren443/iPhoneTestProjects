#import <Cocoa/Cocoa.h>


@interface Class1 : NSObject

@end
