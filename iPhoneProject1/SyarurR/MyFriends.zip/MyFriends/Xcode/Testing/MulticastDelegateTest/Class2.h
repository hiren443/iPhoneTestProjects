#import <Cocoa/Cocoa.h>


@interface Class2 : NSObject

@end
