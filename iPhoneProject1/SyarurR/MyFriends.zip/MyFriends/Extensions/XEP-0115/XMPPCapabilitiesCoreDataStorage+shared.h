//
//  XMPPCapabilitiesCoreDataStorage+shared.h
//  talk
//
//  Created by Eric Chamberlain on 10/2/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "XMPPCapabilitiesCoreDataStorage.h"

@interface XMPPCapabilitiesCoreDataStorage(shared)

+ (XMPPCapabilitiesCoreDataStorage *)sharedXMPPCapabilitiesCoreDataStorage;

@end
