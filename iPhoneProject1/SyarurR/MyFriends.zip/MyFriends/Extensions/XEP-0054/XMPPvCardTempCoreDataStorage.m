//
//  XMPPvCardTempCoreDataStorage.m
//  XEP-0054 vCard-temp
//
//  Created by Eric Chamberlain on 3/18/11.
//  Copyright (c) 2011 RF.com. All rights reserved.
//

#import "XMPPvCardTempCoreDataStorage.h"
#import "XMPPvCardCoreDataStorage.h"


@implementation XMPPvCardTempCoreDataStorage
@dynamic vCardTemp;
@dynamic vCard;


@end
