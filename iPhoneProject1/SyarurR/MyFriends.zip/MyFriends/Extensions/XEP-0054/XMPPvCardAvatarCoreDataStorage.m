//
//  XMPPvCardAvatarCoreDataStorage.m
//  XEP-0054 vCard-temp
//
//  Created by Eric Chamberlain on 3/18/11.
//  Copyright (c) 2011 RF.com. All rights reserved.
//

#import "XMPPvCardAvatarCoreDataStorage.h"
#import "XMPPvCardCoreDataStorage.h"


@implementation XMPPvCardAvatarCoreDataStorage
@dynamic photoData;
@dynamic vCard;


@end
