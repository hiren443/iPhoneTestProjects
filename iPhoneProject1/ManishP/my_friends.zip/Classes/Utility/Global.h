//
//  Global.h
//  TimeBang
//
//  Created by Manish Patel on 26/03/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface Global : NSObject
{

}

+ (void)showAlert:(NSString *)title message:(NSString *)message;

@end
