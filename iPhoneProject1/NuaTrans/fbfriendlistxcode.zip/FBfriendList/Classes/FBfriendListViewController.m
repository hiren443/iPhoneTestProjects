//
//  FBfriendListViewController.m
//  FBfriendList
//
//  Created by SmartJobDevelopers on 8/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FBfriendListViewController.h"

@implementation FBfriendListViewController

@synthesize session = _session;
@synthesize postGradesButton = _postGradesButton;
@synthesize logoutButton = _logoutButton;
@synthesize loginDialog = _loginDialog;
@synthesize facebookName = _facebookName;
@synthesize posting = _posting;



-(void)viewWillAppear:(BOOL)animated{
	//for FB
	static NSString* kApiKey = @"145062165564860";
	static NSString* kApiSecret = @"09d5ff4260a342ea3012cf2888e47d4e";
	_session = [[FBSession sessionForApplication:kApiKey secret:kApiSecret delegate:self] retain];
	
	// Load a previous session from disk if available.  Note this will call session:didLogin if a valid session exists.
	
	myList =[[NSArray alloc]init];
	
	
	fbnamelist =[[NSMutableArray alloc]init];
	
	
}
-(IBAction)btnFB{
	_posting = YES;
	// If we're not logged in, log in first...
	if (![_session isConnected]) {
		self.loginDialog = nil;
		_loginDialog = [[FBLoginDialog alloc] init];	
		[_loginDialog show];
		//[_session resume];
		
	}
	// If we have a session and a name, post to the wall!
	else if (_facebookName != nil) {
		
		[self postToWall];
		[self request:self didLoad:self];
	}
	
	[view removeFromSuperview];
	[self.view addSubview:loadingviw];
	[activityIndicator startAnimating];
}
- (IBAction)postGradesTapped:(id)sender {
	/*_posting = YES;
	 // If we're not logged in, log in first...
	 if (![_session isConnected]) {
	 self.loginDialog = nil;
	 _loginDialog = [[FBLoginDialog alloc] init];	
	 [_loginDialog show];	
	 }
	 // If we have a session and a name, post to the wall!
	 else if (_facebookName != nil) {
	 [self postToWall];
	 }*/
	// Otherwise, we don't have a name yet, just wait for that to come through.
}

- (IBAction)logoutButtonTapped:(id)sender {
	[_session logout];
	
}


#pragma mark FBSessionDelegate methods

- (void)session:(FBSession*)session didLogin:(FBUID)uid {
	[self getFacebookName];
}

/*- (void)session:(FBSession*)session willLogout:(FBUID)uid {
	_logoutButton.hidden = YES;
	_facebookName = nil;
}*/

#pragma mark Get Facebook Name Helper


- (void)getFacebookName {
	/*NSString* fql = [NSString stringWithFormat:
					 @"select uid,name from user where uid == %lld", _session.uid];
	NSDictionary* params = [NSDictionary dictionaryWithObject:fql forKey:@"query"];
	[[FBRequest requestWithDelegate:self] call:@"facebook.fql.query" params:params];*/
	
	
	NSString* fql = [NSString stringWithFormat:
					 @"select uid from user where uid == %lld", _session.uid];
	
	
	NSLog(@"the user id:%@",fql);
	
	NSDictionary* params = [NSDictionary dictionaryWithObject:fql forKey:@"query"];
	_session = _session;
	[[FBRequest requestWithDelegate:self] call:@"facebook.friends.get" params:params];
	
}

#pragma mark FBRequestDelegate methods

/*- (void)request:(FBRequest*)request didLoad:(id)result {
	if ([request.method isEqualToString:@"facebook.fql.query"]) {
		NSArray* users = result;
		NSDictionary* user = [users objectAtIndex:0];
		NSString* name = [user objectForKey:@"name"];
		self.facebookName = name;		
		_logoutButton.hidden = NO;
		[_logoutButton setTitle:[NSString stringWithFormat:@"Facebook: Logout as %@", name] forState:UIControlStateNormal];
		if (_posting) {
			[self postToWall];
			_posting = NO;
		}
	}
}*/

#pragma mark Post to Wall Helper

- (void)postToWall {
	
	NSString*fbhead=@"Word App";
	
	FBStreamDialog* dialog = [[[FBStreamDialog alloc] init] autorelease];
	dialog.userMessagePrompt = @"";
			
		
		dialog.attachment = [NSString stringWithFormat:@"{\"name\":\"%@\",\"href\":\"http://www.facebook.com/apps/application.php?id=165025313574090&sk=info/\",\"caption\":\"\",\"description\":\"\",\"media\":[{\"type\":\"image\",\"src\":\"http:\",\"href\":\"http://www.facebook.com/apps/application.php?id=165025313574090&sk=info\"}]}",
							 fbhead];
	
	
	
	dialog.actionLinks = @"[{\"text\":\"Get MyGrades!\",\"href\":\"http://www.facebook.com/apps/application.php?id=165025313574090&sk=info/\"}]";
	[dialog show];	
}






- (void)request:(FBRequest*)request didLoad:(id)result {
	//if(myList==nil) {
		
	
	
	
	
	
		NSArray* users = result;
	
		
	
		myList =[[NSArray alloc] initWithArray: users];
		for(i=0;i<[users count];i++) {
			NSDictionary* user = [users objectAtIndex:i];
			NSString* uid = [user objectForKey:@"uid"];
			NSString* fql = [NSString stringWithFormat:@"select name from user where uid == %@", uid];
			
			NSDictionary* params = [NSDictionary dictionaryWithObject:fql forKey:@"query"];
			[[FBRequest requestWithDelegate:self] call:@"facebook.fql.query" params:params];
						
			
								
		}
	
	
	
	//}
	//else {
		//NSArray* users = result;
	
	
		NSDictionary* user = [users objectAtIndex:0];
		NSString* name = [user objectForKey:@"name"];
	
	

	if (name==nil) {
		
	}
	
	else {
		[fbnamelist addObject:name];
		netfbid=[users count];
		
		localfbid=[fbnamelist count];
		[fbtable reloadData];
		
										
				
	}
	[self performSelector:@selector(viewcall) withObject:nil afterDelay:5.0];

	
		
		//txtView.text=[NSString localizedStringWithFormat:@"%@%@,\n",txtView.text,name];
	
		
	//}
	
		
	
		
}
-(void)viewcall{
	[loadingviw removeFromSuperview];
	[self.view addSubview:tabviw];
	[activityIndicator stopAnimating];
	
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tabviw {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tabviw numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
	
	return [fbnamelist count];
	
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tabviw cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tabviw dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    
    // Configure the cell...
	//cell.text = mainid;
	cell.text=[fbnamelist objectAtIndex:indexPath.row];
	
	//cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.font = [UIFont fontWithName:@"AmericanTypewriter" size:14.0];
	fbtable.backgroundColor=[UIColor clearColor];
	cell.textAlignment = UITextAlignmentCenter;

	//fbtable.separatorColor=[UIColor clearColor];
		
    return cell;
}
- (void)tableView:(UITableView *)tabviw didSelectRowAtIndexPath:(NSIndexPath *)indexPath {

}
/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

@end
