//
//  FBfriendListAppDelegate.h
//  FBfriendList
//
//  Created by SmartJobDevelopers on 8/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FBfriendListViewController;

@interface FBfriendListAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    FBfriendListViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet FBfriendListViewController *viewController;

@end

