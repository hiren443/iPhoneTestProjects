//
//  FBfriendListViewController.h
//  FBfriendList
//
//  Created by SmartJobDevelopers on 8/25/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import"FBConnect/FBConnect.h"

@interface FBfriendListViewController : UIViewController {
	
	
	// facebook
	
	FBSession* _session;
	FBLoginDialog *_loginDialog;
	UIButton *_postGradesButton;
	UIButton *_logoutButton;
	NSString *_facebookName;
	BOOL _posting;
	NSArray*myList;
	IBOutlet UITextView*txtView;
	
	IBOutlet UITableView*fbtable;
	
	NSMutableArray*fbnamelist;
	
	IBOutlet UIView*tabviw;
	 IBOutlet UIActivityIndicatorView *activityIndicator;
	IBOutlet UIView*loadingviw;
	IBOutlet UIView*view;
	NSInteger netfbid;
	NSInteger localfbid;
	NSInteger i;

}
-(IBAction)btnFB;

@property (nonatomic, retain) FBSession *session;
@property (nonatomic, retain) IBOutlet UIButton *postGradesButton;
@property (nonatomic, retain) IBOutlet UIButton *logoutButton;
@property (nonatomic, retain) FBLoginDialog *loginDialog;
@property (nonatomic, copy) NSString *facebookName;
@property (nonatomic, assign) BOOL posting;


@end

