//
//  RootViewController.h
//  FacebookTestProject
//
//  Created by Saad Mubarak on 8/16/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UITableViewController {

    NSArray *friendsArray;
}
@property(nonatomic,retain) NSArray *friendsArray;

@end
