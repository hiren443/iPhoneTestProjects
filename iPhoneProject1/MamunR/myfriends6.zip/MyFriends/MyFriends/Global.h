//
//  Global.h
//  Komutr
//
//  Created by Mamun Ar Rashid on 7/24/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import <UIKit/UIKit.h>
#import "FBSession.h"
#import "FBConnect.h"

FBSession* session;