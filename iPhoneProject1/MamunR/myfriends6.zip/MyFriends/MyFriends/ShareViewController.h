//
//  ShareViewController.h
//  Komutr
//
//  Created by Mamun on 15/05/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FBSession.h"
#import "FBConnect.h"


@interface ShareViewController : UIViewController<FBDialogDelegate, FBSessionDelegate, FBRequestDelegate> {

	

	IBOutlet UIButton *btnFacebook;
	
    
    bool loginbuttonTap;
}

@property(nonatomic,retain) IBOutlet UIButton *btnFacebook;



@property(nonatomic,retain) FBSession* session;


- (IBAction)btnFacebookPressed:(id)sender;


@end
