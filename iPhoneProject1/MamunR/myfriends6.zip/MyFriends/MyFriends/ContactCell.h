//
//  ContactCell.h
//  AdvancePhonebook
//
//  Created by Mamun on 14/04/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ContactCell : UITableViewCell {
	
	IBOutlet UILabel *name;
	IBOutlet UILabel *phone;
	IBOutlet UILabel *status;
	IBOutlet UIImageView *photo;
	
	
}
@property (nonatomic, retain)IBOutlet UILabel *name;
@property (nonatomic, retain)IBOutlet UILabel *phone;
@property (nonatomic, retain)IBOutlet UILabel *status;
@property (nonatomic, retain)IBOutlet UIImageView *photo;

- (id)initWithFrame:(CGRect)frame reuseIdentifier:(NSString *)reuseIdentifier __OSX_AVAILABLE_BUT_DEPRECATED(__MAC_NA,__MAC_NA,__IPHONE_2_0,__IPHONE_3_0);

@end
