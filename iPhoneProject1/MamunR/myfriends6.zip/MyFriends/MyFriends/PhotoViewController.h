//
//  PhotoViewController.h
//  Komutr
//
//  Created by Mamun Ar Rashid on 7/29/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import <AddressBookUI/AddressBookUI.h>
#import "ContactCell.h"
#import "FBSession.h"
#import "FBConnect.h"



@interface PhotoViewController : UIViewController<FBSessionDelegate, FBRequestDelegate> {
	IBOutlet UITableView *tableView;
	NSMutableArray *dataArray;
	IBOutlet ContactCell  *tblCell;
    bool isPhotoList;
    //UINavigationController *navigator;
  
}
//@property(nonatomic,retain)UINavigationController *navigator;

@property(nonatomic,retain) UITableView	*tableView;
@property(nonatomic,retain) NSMutableArray	*dataArray;
@end
