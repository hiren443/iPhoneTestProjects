//
//  Contants.m
//  AdvancePhonebook
//
//  Created by Mamun on 11/04/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PhotoViewController.h"

#import "Global.h"

@implementation PhotoViewController
@synthesize tableView,dataArray;




// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	dataArray=[[NSMutableArray alloc] init];
    
    isPhotoList=FALSE;
    
    static NSString* kApiKey = @"145062165564860";
	static NSString* kApiSecret = @"09d5ff4260a342ea3012cf2888e47d4e";
	session = [[FBSession sessionForApplication:kApiKey secret:kApiSecret delegate:self] retain];
    
    
    //  NSLog(@"Load");
	// Load a previous session from disk if available.  Note this will call session:didLogin if a valid session exists.
	[session resume];
    
    
    
    
    

     
     NSLog(@"array f %@",dataArray);
	[self.tableView reloadData]; 
	
}


#pragma mark FBRequestDelegate methods

- (void)session:(FBSession*)_session didLogin:(FBUID)uid {
    
    if(isPhotoList)
    {
        NSLog(@"Photo=");
        
        int uid2=61413998;
        
        NSString* fql = [NSString stringWithFormat:
                         @"SELECT pid, caption, aid, owner, link, src_big, src_small, created, modified FROM photo WHERE aid IN (SELECT aid FROM album WHERE owner IN (SELECT uid2 FROM friend WHERE uid1=%lld ) AND owner=%d  )", _session.uid,uid2];
        NSDictionary* params = [NSDictionary dictionaryWithObject:fql forKey:@"query"];
        [[FBRequest requestWithDelegate:self] call:@"facebook.fql.query" params:params];
        NSLog(@"Photo=");
    }
    else
    {
    
    NSLog(@"frends1=");
    
    NSString* fql = [NSString stringWithFormat:
					 @"SELECT name,uid,pic_square FROM user WHERE uid IN ( SELECT uid2 FROM friend WHERE uid1=%lld )", _session.uid];
	NSDictionary* params = [NSDictionary dictionaryWithObject:fql forKey:@"query"];
	[[FBRequest requestWithDelegate:self] call:@"facebook.fql.query" params:params];
    NSLog(@"frends2=");
    }
   
}

- (void)request:(FBRequest*)request didLoad:(id)result {
    
 
    
	if ([request.method isEqualToString:@"facebook.fql.query"]) {
        
           // NSLog(@"frends=%@",result);
        
        if(isPhotoList)
        {
             NSLog(@"PhotoList=%@",result);
            
        }
        else
        {
        
        for (int i = 0; i < [result count]-1; i++) {
            NSDictionary* user = [result objectAtIndex:i];
            
            NSString* name = [user objectForKey:@"name"];
            
             NSString* uid = [user objectForKey:@"uid"];
            
          //  NSDictionary* status = [user objectForKey:@"status"];
            
            
            
           // NSLog(@"Friend uid=%@",result);
                    
                    
                    NSMutableDictionary    *dic1 = [[NSMutableDictionary alloc]initWithCapacity:3];
                    [dic1 setObject:name forKey:@"name"];
                    
                    [dic1 setObject:[user objectForKey:@"pic_square"] forKey:@"image"];
                    
                  
                        [dic1 setObject:uid forKey:@"phone"];
                   
                    
                    [dataArray addObject:dic1];
                
            
            
        }
        
        [self.tableView reloadData];
        }
    }
       
        
         isPhotoList=FALSE;
        //_logoutButton.hidden = NO;
		//[_logoutButton setTitle:[NSString stringWithFormat:@"Facebook: Logout as %@", name] forState://///UIControlStateNormal];
		///if (_posting) {
		//	[self postToWall];
        //_posting = NO;
		//}
	
}

/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

    

    
    
   
   
    
    
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return [self.dataArray count];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
	
	//NSMutableArray *inerdataArray = [[[NSString stringWithFormat:@"%@",[[tableDataArray objectAtIndex:0] valueForKey:@"array"]] propertyList] mutableCopy];
	
	
	return 72;  
}
// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView1 cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
	static NSString *MyIdentifier = @"MyIdentifier";
	MyIdentifier = @"tblCellView";
	
	ContactCell *cell = (ContactCell *)[tableView dequeueReusableCellWithIdentifier:MyIdentifier];
	
	if(cell == nil) {
		[[NSBundle mainBundle] loadNibNamed:@"ContactCell" owner:self options:nil];
		cell = tblCell;
		cell.selectionStyle=UITableViewCellSelectionStyleBlue;
	}
	cell.name.text=[[dataArray objectAtIndex:indexPath.row] valueForKey:@"name"];
	cell.phone.text=[[dataArray objectAtIndex:indexPath.row] valueForKey:@"phone"];
    
    cell.photo.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL 
                                                                             URLWithString:[[dataArray objectAtIndex:indexPath.row] valueForKey:@"image"]]]];
    
    
    //  cell.photo.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL 
    //                               http:]]];
    
    
    //UIImage *image = [UIImage imageNamed: [[dataArray objectAtIndex:indexPath.row] valueForKey:@"image"]];
    
    
    
    
    
	
	return cell;
}
- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
