//
//  ShareViewController.m
//  Komutr
//
//  Created by Mamun on 15/05/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//



#import "PhotoViewController.h"
#import "ShareViewController.h"

#import "FBLoginDialog.h"
#import "Global.h"



@implementation ShareViewController
@synthesize btnFacebook,session;

// The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
/*
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization.
    }
    return self;
}
*/

- (IBAction)btnFacebookPressed:(id)sender
{
	
    // If we're not logged in, log in first...
	if (![session isConnected]) {
	
        loginbuttonTap=TRUE;

        
		FBLoginDialog *_loginDialog = [[FBLoginDialog alloc] init];	
        
        NSLog(@"Showww");
		[_loginDialog show];
        
           
        
       
	}
    else
    {
        PhotoViewController *plans = [[PhotoViewController alloc]initWithNibName:@"PhotoViewController" bundle:[NSBundle mainBundle]];
        [self.navigationController pushViewController:plans animated:YES];
        [plans release]; 
            
    }
		
}

- (void)session:(FBSession*)session willLogout:(FBUID)uid {
    
   
}





- (void)session:(FBSession*)_session didLogin:(FBUID)uid {

    if(loginbuttonTap)
    {
    FBPermissionDialog* dialog = [[FBPermissionDialog alloc] initWithSession:_session];
    dialog.delegate = self;
    dialog.permission = @"read_stream, publish_stream, friends_location,friends_birthday,	friends_photos,friends_status,read_friendlists";
    [dialog show];
        
        PhotoViewController *plans = [[PhotoViewController alloc]initWithNibName:@"PhotoViewController" bundle:[NSBundle mainBundle]];
        [self.navigationController pushViewController:plans animated:YES];
        [plans release]; 
        
    loginbuttonTap=FALSE;
    }
    
   
    
  // [btnFacebook setTitleColor:UIColor.greenColor forState:UIControlStateNormal];
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
    loginbuttonTap=FALSE;
	
	// Set these values from your application page on http://www.facebook.com/developers
	// Keep in mind that this method is not as secure as using the sessionForApplication:getSessionProxy:delegate method!
	// These values are from a dummy facebook app I made called MyGrades - feel free to play around!
	static NSString* kApiKey = @"145062165564860";
	static NSString* kApiSecret = @"09d5ff4260a342ea3012cf2888e47d4e";
	session = [[FBSession sessionForApplication:kApiKey secret:kApiSecret delegate:self] retain];
    
    
  //  NSLog(@"Load");
	// Load a previous session from disk if available.  Note this will call session:didLogin if a valid session exists.
	[session resume];
	
	




	
	
	
	
	
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
