//
//  NameTableView.h
//  oAuth2Test
//
//  Created by Yasir on 8/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "oAuth2TestAppDelegate.h"

@interface NameTableView : UITableViewController {
    
    
    oAuth2TestAppDelegate * appDelegate;
}

@end
