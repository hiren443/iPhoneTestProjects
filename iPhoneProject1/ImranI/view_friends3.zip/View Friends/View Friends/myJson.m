//
//  SocialAppAppDelegate.m
//  SocialApp
//
//  Created by Imran Ishaq on 4/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "myJson.h"
#import "View_FriendsAppDelegate.h"


@implementation Json

+(void) stopSpinner
{
	[APPDELEGATE hideBusyView];
}

+(void) startSpinner
{
    [APPDELEGATE showBusyView];
}


+ (NSString *)stringWithUrl:(NSURL *)url
{
	NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url
												cachePolicy:NSURLRequestReturnCacheDataElseLoad
											timeoutInterval:30];
	// Fetch the JSON response
	NSData *urlData;
	NSURLResponse *response;
	NSError *error;
	
	// Make synchronous request
	urlData = [NSURLConnection sendSynchronousRequest:urlRequest
									returningResponse:&response
												error:&error];
	
 	// Construct a String around the Data from the response
    
	return [[NSString alloc] initWithData:urlData encoding:NSUTF8StringEncoding];
}

+ (id) objectWithUrl:(NSURL *)url
{
	NSThread * t1 = [[NSThread alloc] initWithTarget:self selector:@selector(startSpinner) object:nil];
	[t1 start];

	SBJsonParser *jsonParser = [SBJsonParser new];
	NSString *jsonString = [self stringWithUrl:url];
	

	[self performSelector:@selector(stopSpinner) withObject:nil];

	[t1 cancel];
	[t1 release];
	
	return [jsonParser objectWithString:jsonString ];
}

+ (id) objectWthString:(NSString *) jsonString
{
	SBJsonParser *jsonParser = [SBJsonParser new];
	return [jsonParser objectWithString:jsonString ];
}




+(id) postToWebwithURL: (NSString *) urlString andBody:(NSString *) requestBody
{
	NSURL * url = [NSURL URLWithString:urlString];
	
	NSMutableURLRequest * theRequest = [[[NSMutableURLRequest alloc] init] autorelease];
	
	NSMutableData *theRequestData = [NSMutableData dataWithBytes: [requestBody UTF8String] length: [requestBody length]];
	
	[theRequest setHTTPBody:theRequestData];
	
	[theRequest setURL:url];
	[theRequest setCachePolicy:NSURLRequestReloadIgnoringCacheData];
	[theRequest setTimeoutInterval:10];
	[theRequest setHTTPMethod:@"POST"];
	[theRequest setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
	[theRequest setValue:[NSString stringWithFormat:@"%d",[requestBody length] ] forHTTPHeaderField:@"Content-Length"];


	NSMutableData * webData = (NSMutableData *) [NSURLConnection sendSynchronousRequest: theRequest returningResponse: nil error: nil ];
	
	NSString * str = [[[NSString alloc] initWithData:webData encoding:NSUTF8StringEncoding] autorelease];
	return [self objectWthString:str];
}


@end
