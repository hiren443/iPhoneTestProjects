//
//  View_FriendsAppDelegate.h
//  View Friends
//
//  Created by Imran Ishaq on 8/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class View_FriendsViewController;

@interface View_FriendsAppDelegate : NSObject <UIApplicationDelegate> {
    IBOutlet UIView*				busyMainView_;
	IBOutlet UIActivityIndicatorView*	busyActivityIndicator_;
     UIWindow *window;

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet View_FriendsViewController *viewController;
- (void)showBusyView;
- (void)hideBusyView;

#define APPDELEGATE \
((View_FriendsAppDelegate*)[UIApplication sharedApplication].delegate)

@end
