//
//  View_FriendsViewController.h
//  View Friends
//
//  Created by Imran Ishaq on 8/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Facebook.h"
@interface View_FriendsViewController : UIViewController 
<FBSessionDelegate, FBRequestDelegate,UITableViewDataSource,UITableViewDelegate> {
    Facebook *facebook;
    NSMutableArray *arrayFriendsList;
    IBOutlet UIButton *btnMyfrindsList;
    IBOutlet UITableView *mytableview;
}
@property (nonatomic, retain) Facebook *facebook;
- (IBAction)buttonClicked:(id)sender;
-(void)GetMyFriendsList;
@end
