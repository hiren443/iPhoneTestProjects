//
//  SocialAppAppDelegate.m
//  SocialApp
//
//  Created by Imran Ishaq on 4/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "JSON.h"
//#import "ASIFormDataRequest.h"

@interface Json : NSObject {
}

+ (NSString *)stringWithUrl:(NSURL *)url;
+ (id) objectWithUrl:(NSURL *)url;
+ (id) objectWthString:(NSString *) jsonString;

+(id) postToWebwithURL: (NSString *) urlString andBody:(NSString *) requestBody;
//+ (id) postFileToWebwithURL: (NSString *) urlString key:(NSString *) key fileData:(NSData *) fileData andFilename:(NSString *) fileName withContentType:(NSString *) contentType;

+(void) stopSpinner;
+(void) startSpinner;
@end
