//
//  View_FriendsViewController.m
//  View Friends
//
//  Created by Imran Ishaq on 8/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "View_FriendsViewController.h"
#import "Friends.h"
#import "JSON.h"
#import "myJson.h"

@implementation View_FriendsViewController

@synthesize facebook;
- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}


#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return [arrayFriendsList count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{	
    return 44;
}
// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *MyIdentifier = @"MyCell";
	
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MyIdentifier];	
	Friends *objMenu = [arrayFriendsList objectAtIndex:[indexPath row]];	
	cell.textLabel.text = objMenu.strFriendName;
	return cell;
}


#pragma mark -
#pragma mark Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
    //	DetailViewController *DVC=[[DetailViewController alloc]initWithNibName:@"DetailViewController" bundle:nil];
    //	DVC.str_GetRecord_ID=[Store_id_Array objectAtIndex:indexPath.row];
    //	[self.view addSubview:DVC.view];
}



#pragma mark - View lifecycle


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
facebook = [[Facebook alloc] initWithAppId:@"145062165564860"];
    mytableview.hidden=YES;
}

- (IBAction)buttonClicked:(id)sender {
    NSArray* permissions = [[NSArray alloc] initWithObjects:
                            @"publish_stream", nil];
    [facebook authorize:permissions delegate:self];
    [permissions release];
}

- (void)fbDidLogin {
    btnMyfrindsList.hidden=YES;
    mytableview.hidden=NO;
    [self GetMyFriendsList];
    [mytableview reloadData];
}

-(void)GetMyFriendsList
{

    arrayFriendsList=[[NSMutableArray alloc]init];
    NSURL *url1= [[NSURL alloc] initWithString:[NSString stringWithFormat:@"https://graph.facebook.com/me/friends?access_token=%@", facebook.accessToken]];
    
	NSDictionary *DicMain = (NSDictionary *) [Json objectWithUrl:url1];
    NSArray *entryArray=[DicMain objectForKey:@"data"];
	for ( NSDictionary *DicTwitterFeeds in entryArray)
	{
        @try
		{
            Friends *objFeed=[[Friends alloc]init];
            objFeed.frndID=[[DicTwitterFeeds objectForKey:@"id"] intValue];
            objFeed.strFriendName=[DicTwitterFeeds objectForKey:@"name"];
            [arrayFriendsList addObject:objFeed];
		}
		@catch (NSException *ep) {
		}
	} 
	


}


-(void)fbDidNotLogin:(BOOL)cancelled {
	NSLog(@"did not login");
}

- (void)request:(FBRequest *)request didLoad:(id)result {
	if ([result isKindOfClass:[NSArray class]]) {
		result = [result objectAtIndex:0];
	}
	NSLog(@"Result of API call: %@", result);
}

- (void)request:(FBRequest *)request didFailWithError:(NSError *)error {
    NSLog(@"Failed with error: %@", [error localizedDescription]);
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
