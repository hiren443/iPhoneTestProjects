//
//  FriendsViewController.m
//  MyFriends
//
//  Created by houssem on 8/16/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "FriendsViewController.h"


@implementation FriendsViewController


#pragma mark -
#pragma mark View lifecycle


- (void)viewDidLoad {
    [super viewDidLoad];

    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}


- (void)viewWillAppear:(BOOL)animated {
	myFriendsList = [[NSMutableArray alloc] initWithObjects:nil];
	MyFriendsAppDelegate *appDelegate =(MyFriendsAppDelegate *)[[UIApplication sharedApplication]delegate];

	FBSession *session = appDelegate._session;
	[self addList:session];
	
    [super viewWillAppear:animated];
}

/*
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
}
*/
/*
- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
}
*/
/*
- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
}
*/
/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations.
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


#pragma mark -
#pragma mark Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    // Return the number of sections.
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    // Return the number of rows in the section.
    return MAX(1,[myFriendsList count]);
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    NSLog(@"created new cell");
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];

	}
    // Configure the cell...
	if (myFriendsList.count>0) {
		cell.textLabel.text= [myFriendsList objectAtIndex:indexPath.row];

	}
    return cell;
}


-(void)addList:(FBSession *)session {

	
	NSString* fql = [NSString stringWithFormat:@"SELECT name,uid FROM user WHERE uid IN ( SELECT uid2 FROM friend WHERE uid1=%lld )",session.uid];
	NSDictionary* params = [NSDictionary dictionaryWithObject:fql forKey:@"query"];
	[[FBRequest requestWithDelegate:self] call:@"facebook.fql.query" params:params];
	
	
}

- (void)request:(FBRequest*)request didLoad:(id)result {
	if([request.method isEqualToString:@"facebook.fql.query"])
	{ 
		int i;
		NSArray* users = result;
		int c = [users count]; 
		NSLog(@"%d",c);
		for(i=0; i < c-2 ;i++)
		{  
			NSDictionary* user = [users objectAtIndex:i]; 
			NSString *name = [user objectForKey:@"name"];
			NSIndexPath *index = [NSIndexPath indexPathForRow:i inSection:0];
			UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:index];
			[myFriendsList addObject:[NSString stringWithFormat:@"%@",name]]; 

			cell.textLabel.text = name;
			NSLog(@"new user %@",name);

		}
		

	}
	[myFriendsList sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
	[self.tableView reloadData];

}




#pragma mark -
#pragma mark Table view delegate



#pragma mark -
#pragma mark Memory management

- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Relinquish ownership any cached data, images, etc. that aren't in use.
}

- (void)viewDidUnload {
    // Relinquish ownership of anything that can be recreated in viewDidLoad or on demand.
    // For example: self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end

