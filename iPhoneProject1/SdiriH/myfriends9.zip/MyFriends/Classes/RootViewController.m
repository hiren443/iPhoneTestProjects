//
//  RootViewController.m
//  MyFriends
//
//  Created by houssem on 8/16/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "RootViewController.h"
#import "MyFriendsAppDelegate.h"

#define _APP_KEY @"145062165564860"
#define _SECRET_KEY @"09d5ff4260a342ea3012cf2888e47d4e"


@implementation RootViewController
@synthesize facebookAlert;
@synthesize usersession;
@synthesize username;
@synthesize post;
@synthesize loginButton;

- (void)viewDidLoad {
	self.navigationController.title=@"title";
	self.navigationController.navigationBar.tintColor= [UIColor blueColor];
	MyFriendsAppDelegate *appDelegate =(MyFriendsAppDelegate *)[[UIApplication sharedApplication]delegate];
	
	if (appDelegate._session == nil){
		appDelegate._session = [FBSession sessionForApplication:_APP_KEY 
														 secret:_SECRET_KEY delegate:self];
	}
	
    [super viewDidLoad];
}
-(void) viewWillAppear:(BOOL)animated{
	MyFriendsAppDelegate *appDelegate =(MyFriendsAppDelegate *)[[UIApplication sharedApplication]delegate];

	if ([appDelegate._session isConnected] == NO) {
		//show proper buttons for login
		user.hidden=YES;
        userMessage.hidden=YES;
		logoutButton.hidden = YES;
	}
	
	else {
		user.hidden=NO;
        userMessage.hidden=NO;
		logoutButton.hidden = NO;
		user.text= self.username;

    }
	
	
	
}

-(IBAction) logout{
	
	MyFriendsAppDelegate *appDelegate =(MyFriendsAppDelegate *)[[UIApplication sharedApplication]delegate];
	[appDelegate._session logout];
	user.hidden=YES;
	userMessage.hidden=YES;
	logoutButton.hidden = YES;
}
/*
 // Override to allow orientations other than the default portrait orientation.
 - (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
 // Return YES for supported orientations
 return (interfaceOrientation == UIInterfaceOrientationPortrait);
 }
 */

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
	[username release];
	[usersession release];
	[loginButton release];
    [super dealloc];
}


- (IBAction) login {
	MyFriendsAppDelegate *appDelegate =(MyFriendsAppDelegate *)[[UIApplication sharedApplication]delegate];

    //self.isDialogShown = YES;
    FBLoginDialog* dialog = [[[FBLoginDialog alloc] initWithSession:appDelegate._session] autorelease];
    dialog.delegate = self;
    [dialog show];
}


- (void)session:(FBSession*)session didLogin:(FBUID)uid {
	self.usersession =session;
    NSLog(@"User with id %lld logged in.", uid);
	[self getFacebookName];
}

- (void)getFacebookName {
	NSString* fql = [NSString stringWithFormat:
					 @"select uid,name from user where uid == %lld", self.usersession.uid];
	NSDictionary* params = [NSDictionary dictionaryWithObject:fql forKey:@"query"];
	[[FBRequest requestWithDelegate:self] call:@"facebook.fql.query" params:params];
	self.post=YES;
}

- (void)request:(FBRequest*)request didLoad:(id)result {
	if ([request.method isEqualToString:@"facebook.fql.query"]) {
		NSArray* users = result;
		NSDictionary* myuser = [users objectAtIndex:0];
		NSString* name = [myuser objectForKey:@"name"];
		self.username = name;		
		user.hidden=NO;
        userMessage.hidden=NO;
		logoutButton.hidden = NO;
		user.text= self.username;
			[self viewFriends];
	}
}

- (void)viewFriends {
	
	FriendsViewController *fvController= [[FriendsViewController alloc]initWithNibName:@"FriendsViewController" bundle:nil];
	[self.navigationController pushViewController:fvController animated:YES];
}



- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
	[textField resignFirstResponder];
	return YES;
}



@end

