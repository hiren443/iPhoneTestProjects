//
//  RootViewController.h
//  MyFriends
//
//  Created by houssem on 8/16/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FriendsViewController.h"
#import "FBConnect/FBConnect.h"

#import "FBConnect/FBSession.h"

@interface RootViewController : UIViewController {
	UIAlertView *facebookAlert;
	FBSession *usersession;
	NSString *username;
	BOOL post;
	NSMutableArray *myList;
	FBLoginButton *loginButton; 
	IBOutlet UILabel *user;
	IBOutlet UILabel *userMessage;
	IBOutlet UIButton *logoutButton;
	
}
@property(nonatomic,retain) FBLoginButton *loginButton; 

@property(nonatomic,retain) UIAlertView *facebookAlert;
@property(nonatomic,retain)  FBSession *usersession;
@property(nonatomic,retain) NSString *username;
@property(nonatomic,assign) BOOL post;
-(void) viewFriends;
- (BOOL)textFieldShouldReturn:(UITextField *)textField;
-(void)getFacebookName;
-(void)postToWall;
-(IBAction) login;
-(IBAction) logout;
@end
