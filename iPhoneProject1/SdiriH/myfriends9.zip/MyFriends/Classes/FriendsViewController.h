//
//  FriendsViewController.h
//  MyFriends
//
//  Created by houssem on 8/16/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyFriendsAppDelegate.h"
#import "FBConnect/FBConnect.h"
#import "FBConnect/FBSession.h"


@interface FriendsViewController : UITableViewController<UITableViewDelegate,UITableViewDataSource> {
	NSArray *myList;
	NSMutableArray *myFriendsList;
	IBOutlet UITableView *tableView;
}
@property(nonatomic, retain) IBOutlet NSArray *myList;
@end
