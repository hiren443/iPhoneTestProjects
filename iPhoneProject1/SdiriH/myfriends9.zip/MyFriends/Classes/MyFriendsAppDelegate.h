//
//  MyFriendsAppDelegate.h
//  MyFriends
//
//  Created by houssem on 8/16/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FBConnect/FBConnect.h"
#import "FBConnect.h"

#import "FBConnect/FBSession.h"
#import "FBConnect/FBConnectGlobal.h"
@class Facebook;

@interface MyFriendsAppDelegate : NSObject <UIApplicationDelegate,FBSessionDelegate> {
    
    UIWindow *window;
    UINavigationController *navigationController;
	FBSession *_session;
	Facebook *facebook;

}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;
@property (nonatomic,retain) FBSession *_session;
@property (nonatomic, retain) Facebook *facebook;

@end

