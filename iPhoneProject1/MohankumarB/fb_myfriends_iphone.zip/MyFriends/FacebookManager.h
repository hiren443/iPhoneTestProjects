//
//  FacebookManager.h
//  MyFriends
//
//  Created by Mohankumar Balakrishnan on 24/08/11.
//  Copyright 2011 Impiger. All rights reserved.
//


#import <foundation/Foundation.h>
#import "FBConnect.h"

@interface FBRequest(relativeurl)
- (NSString *) relativeUrl;
@end

@implementation FBRequest(relativeurl)

- (NSString *) relativeUrl{
    
    static NSString* kGraphBaseURL = @"https://graph.facebook.com/";
    
    NSString *rUrl = [self.url stringByReplacingOccurrencesOfString:kGraphBaseURL withString:@""]; 
    
    return rUrl;
    
}

@end

@interface FacebookManager : NSObject <FBSessionDelegate,FBRequestDelegate>{
    
    Facebook *facebook;

}

@property (nonatomic, retain) Facebook *facebook;

+ (id)sharedManager;

@end