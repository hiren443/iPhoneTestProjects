//
//  CustomCell.h
//  MyFriends
//
//  Created by Mohankumar Balakrishnan on 26/08/11.
//  Copyright 2011 Impiger. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface CustomCell : UITableViewCell {
    IBOutlet UILabel *nameLbl;
    IBOutlet UIImageView *profileImageView;
    
}

- (void)setNameLabelText:(NSString *)_name;
- (void)setProfileImage:(UIImage *)_image;

@end
