//
//  FriendsListViewController.m
//  MyFriends
//
//  Created by Mohankumar Balakrishnan on 26/08/11.
//  Copyright 2011 Impiger. All rights reserved.
//

#import "FriendsListViewController.h"


@implementation FriendsListViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)dealloc
{   [activityIndicator release];
    [dataSource release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setTitle:@"My Friends"];
    [self.navigationItem setHidesBackButton:FALSE];
    dataSource = [[NSMutableArray alloc] initWithCapacity:20];
    
    sharedManager = [FacebookManager sharedManager];
    
    [sharedManager.facebook requestWithGraphPath:@"me/friends" andDelegate:(id)self];
    
    [list setSeparatorColor:[UIColor clearColor]];
    
    activityIndicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(0, 0, 20, 20)];
    UIBarButtonItem * barButton = [[UIBarButtonItem alloc] initWithCustomView:activityIndicator];
    [[self navigationItem] setRightBarButtonItem:barButton];
    
    [barButton release];
    [activityIndicator startAnimating];

}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

-(void) prepareImageDownloadRequest:(NSArray *)imageArray {
    
    for (int i=0,cnt=[imageArray count];i<cnt;i++) {
        
        NSDictionary *friendInfo=(NSDictionary *)[imageArray objectAtIndex:i];
        
        NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
        
        NSString *pngFilePath = [NSString stringWithFormat:@"%@/%@.png",docDir,[friendInfo objectForKey:@"id"]];
        
        BOOL fileExists = [[NSFileManager defaultManager] fileExistsAtPath:pngFilePath];
        if (!fileExists) {
            NSString *imagePath=[NSString stringWithFormat:@"%@/picture",[friendInfo objectForKey:@"id"]];
            [sharedManager.facebook requestWithGraphPath:imagePath andDelegate:(id)self];
        }
    }
    
}

-(void) saveDataAsImage:(id)data withFileName:(NSString *) filename{
    
    NSData *imageData=(NSData *)data;
    
	UIImage *image = [[UIImage alloc] initWithData:imageData];
    
    NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];

	NSString *pngFilePath = [NSString stringWithFormat:@"%@/%@.png",docDir,filename];
	NSData *pngImageData = [NSData dataWithData:UIImagePNGRepresentation(image)];
	[pngImageData writeToFile:pngFilePath atomically:YES];
    
    [image release]; 
    
    [list reloadData];
    
}

#pragma mark ------------------FBRequestDelegate --------------------------
- (void)requestLoading:(FBRequest *)request{
    
}

- (void)request:(FBRequest *)request didLoad:(id)result{

    NSRange range;
    
    NSString *substring=[NSString stringWithString:@"me/friends"];
    range =[[request.url lowercaseString] rangeOfString:[substring lowercaseString]];
    
    if(range.location != NSNotFound)
    {
        NSArray *arr=[NSArray arrayWithArray:(NSArray *)[result objectForKey:@"data"]];
        
        [dataSource addObjectsFromArray:arr];
        [list setSeparatorColor:[UIColor grayColor]];
        [list reloadData];
        [self prepareImageDownloadRequest:arr];
        [activityIndicator stopAnimating];
    }
    substring=nil;
    
    substring=[NSString stringWithString:@"picture"];
    range =[[request.url lowercaseString] rangeOfString:[substring lowercaseString]];
    
    if(range.location != NSNotFound)
    {
        NSString *friendid=[[request.url stringByDeletingLastPathComponent] lastPathComponent];
        [self saveDataAsImage:result withFileName:friendid];
        
    }
}
#pragma mark --------------TableView Delegate----------------------------------

// Customize the number of sections in the table view.
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [dataSource count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 70.0;
}
// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"friendlist";
	
	CustomCell *cell = (CustomCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
	if(cell == nil) {
		[[NSBundle mainBundle] loadNibNamed:@"CustomCellIB" owner:self options:nil];
		cell = myCell;
	}
	NSDictionary *friend=(NSDictionary *)[dataSource objectAtIndex:indexPath.row];
	[cell setNameLabelText:[friend objectForKey:@"name"]];
    
    NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    
	NSString *pngFilePath = [NSString stringWithFormat:@"%@/%@.png",docDir,[friend objectForKey:@"id"]];

    
    UIImage *img =[[UIImage alloc] initWithContentsOfFile:pngFilePath];

    [cell setProfileImage:img];

    [img release];
    
	return cell;
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
 {
 if (editingStyle == UITableViewCellEditingStyleDelete)
 {
 // Delete the row from the data source.
 [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
 }
 else if (editingStyle == UITableViewCellEditingStyleInsert)
 {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
 }   
 }
 */

/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
 {
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
 {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    /*
     <#DetailViewController#> *detailViewController = [[<#DetailViewController#> alloc] initWithNibName:@"<#Nib name#>" bundle:nil];
     // ...
     // Pass the selected object to the new view controller.
     [self.navigationController pushViewController:detailViewController animated:YES];
     [detailViewController release];
     */
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

@end
