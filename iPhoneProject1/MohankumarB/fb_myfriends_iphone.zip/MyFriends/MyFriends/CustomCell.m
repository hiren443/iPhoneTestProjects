//
//  CustomCell.m
//  MyFriends
//
//  Created by Mohankumar Balakrishnan on 26/08/11.
//  Copyright 2011 Impiger. All rights reserved.
//

#import "CustomCell.h"


@implementation CustomCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setNameLabelText:(NSString *)_name{
    
    [nameLbl setText:_name];

}
- (void)setProfileImage:(UIImage *)_image{
    
    [profileImageView setImage:_image];
    
}

- (void)dealloc
{
    [super dealloc];
}

@end
