//
//  main.m
//  MyFriends
//
//  Created by Mohankumar Balakrishnan on 23/08/11.
//  Copyright 2011 Impiger. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
