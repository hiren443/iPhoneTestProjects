//
//  MyFriendsAppDelegate.h
//  MyFriends
//
//  Created by Mohankumar Balakrishnan on 23/08/11.
//  Copyright 2011 Impiger. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MyFriendsAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet UINavigationController *navigationController;

@end
