//
//  MyFriendsViewController.h
//  MyFriends
//
//  Created by Mohankumar Balakrishnan on 23/08/11.
//  Copyright 2011 Impiger. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface MyFriendsViewController : UIViewController {
    
}

-(IBAction) myFriendsBtnClicked:(id)sender;

@end
