//
//  FriendsListViewController.h
//  MyFriends
//
//  Created by Mohankumar Balakrishnan on 26/08/11.
//  Copyright 2011 Impiger. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FacebookManager.h"
#import "CustomCell.h"

@interface FriendsListViewController : UIViewController {
    FacebookManager *sharedManager;
    NSMutableArray *dataSource;
    IBOutlet UITableView *list;
    IBOutlet CustomCell *myCell;
    UIActivityIndicatorView *activityIndicator;
}

@end
