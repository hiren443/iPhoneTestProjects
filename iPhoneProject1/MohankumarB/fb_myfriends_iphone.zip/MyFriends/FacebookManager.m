//
//  FacebookManager.m
//  MyFriends
//
//  Created by Mohankumar Balakrishnan on 24/08/11.
//  Copyright 2011 Impiger. All rights reserved.
//

#import "FacebookManager.h"

static FacebookManager *manager = nil;

@implementation FacebookManager

@synthesize facebook;

#pragma mark Singleton Methods
+ (id)sharedManager {
    @synchronized(self) {
        if(manager == nil)
            manager = [[super allocWithZone:NULL] init];
    }
    return manager;
}
+ (id)allocWithZone:(NSZone *)zone {
    return [[self sharedManager] retain];
}
- (id)copyWithZone:(NSZone *)zone {
    return self;
}
- (id)retain {
    return self;
}
- (unsigned)retainCount {
    return UINT_MAX; 
}
- (void)release {

}
- (id)autorelease {
    return self;
}
- (id)init {
    if ((self = [super init])) {
        
        facebook = [[Facebook alloc] initWithAppId:@"145062165564860"];
        
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        if ([defaults objectForKey:@"FBAccessTokenKey"] 
            && [defaults objectForKey:@"FBExpirationDateKey"]) {
            facebook.accessToken = [defaults objectForKey:@"FBAccessTokenKey"];
            facebook.expirationDate = [defaults objectForKey:@"FBExpirationDateKey"];
        }
        if (![facebook isSessionValid]) {
            [facebook authorize:nil delegate:(id)self];
        }
    
    }
    return self;
}
- (void)dealloc {
    
    [facebook release];
    [super dealloc];
}

#pragma mark ----------------------- FBSessionDelegate---------------------

- (void)fbDidLogin {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:[facebook accessToken] forKey:@"FBAccessTokenKey"];
    [defaults setObject:[facebook expirationDate] forKey:@"FBExpirationDateKey"];
    [defaults synchronize];
    
    NSLog(@"Login sucess");
    
}

#pragma mark ------------------FBRequestDelegate --------------------------


- (void)request:(FBRequest *)request didLoad:(id)result{
    
    NSLog(@"Response in Manager: %@",result);
    [request relativeUrl];
}

@end