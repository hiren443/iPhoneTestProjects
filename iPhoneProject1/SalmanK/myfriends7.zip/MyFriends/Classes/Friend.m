//
//  Friend.m
//  oAuth2Test
//
//  Created by Mac on 8/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
/* M Salman Kahlid --Copy righted- certified-
 DO not reuse
 */
#import "Friend.h"


@implementation Friend
@synthesize name,ID;
@end
