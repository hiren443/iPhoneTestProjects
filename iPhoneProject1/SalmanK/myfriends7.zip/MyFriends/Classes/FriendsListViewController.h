//
//  FriendsListViewController.h
//  oAuth2Test
//
//  Created by Mac on 8/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

/* M Salman Kahlid --Copy righted- certified-
 DO not reuse
 */

#import <UIKit/UIKit.h>


@interface FriendsListViewController : UIViewController {

}
@property (nonatomic , retain) NSMutableArray *friendsList;
@end
