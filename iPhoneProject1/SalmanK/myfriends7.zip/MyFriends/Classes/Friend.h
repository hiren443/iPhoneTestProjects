//
//  Friend.h
//  oAuth2Test
//
//  Created by Mac on 8/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

/* M Salman Kahlid --Copy righted- certified-
 DO not reuse
 */

#import <Foundation/Foundation.h>


@interface Friend : NSObject {

}
@property (nonatomic, retain) NSString *ID;
@property (nonatomic ,retain) NSString *name;

@end
