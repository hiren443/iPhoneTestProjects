//
//  FriendListViewController.h
//  fb
//
//  Created by Mac on 8/22/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface FriendListViewController : UITableViewController {
    
    NSMutableArray *data;
}
@property (nonatomic,retain) NSMutableArray *data;
@end
