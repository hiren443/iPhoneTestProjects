//
//  Constant.h
//  MyFriends
//
//  Created by mac on 21/08/11.
//  Copyright 2011 Emblemtechnologies Private Limited. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kFacebookAppID @"145062165564860"