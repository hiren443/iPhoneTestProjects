//
//  MyFriendAppDelegate.h
//  MyFriend
//
//  Created by admin on 23/08/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MyFriendViewController;

@interface MyFriendAppDelegate : NSObject <UIApplicationDelegate>

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet MyFriendViewController *viewController;

@end
