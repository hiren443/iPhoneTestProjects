//
//  MyFriendViewController.m
//  MyFriend
//
//  Created by admin on 23/08/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MyFriendViewController.h"
#import "FBConnect.h"
#import "Facebook.h"
#import "FBRequest.h"
#import "FBDialog.h"
@implementation MyFriendViewController
@synthesize facebook;
- (IBAction)Viewfriend:(id)sender {
    NSArray* permissions = [[NSArray alloc] initWithObjects:@"read_friendlists", nil];
    [facebook authorize:permissions];
    
    [permissions release];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"FBAccessTokenKey"] 
        && [defaults objectForKey:@"FBExpirationDateKey"]) {
        facebook.accessToken = [defaults objectForKey:@"FBAccessTokenKey"];
        facebook.expirationDate = [defaults objectForKey:@"FBExpirationDateKey"];
    }
    
    if (![facebook isSessionValid]) {
        [facebook authorize:permissions];
    }
}


- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url {
    
    return [facebook handleOpenURL:url]; 
}
- (void)fbDidLogin {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:[facebook accessToken] forKey:@"FBAccessTokenKey"];
    [defaults setObject:[facebook expirationDate] forKey:@"FBExpirationDateKey"];
    [facebook requestWithGraphPath:@"me" andDelegate:nil];
    [facebook requestWithGraphPath:@"me/friends" andDelegate:nil];
    [defaults synchronize];
    
}
- (void)dealloc
{
    
    [facebook release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    facebook = [[Facebook alloc] initWithAppId:@"145062165564860" andDelegate:self];
    [super viewDidLoad];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
