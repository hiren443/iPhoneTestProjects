//
//  MyFriendViewController.h
//  MyFriend
//
//  Created by admin on 23/08/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Facebook.h"
@interface MyFriendViewController : UIViewController
<FBSessionDelegate, FBRequestDelegate>{
 Facebook *facebook;
}
@property (nonatomic, retain) Facebook *facebook;
- (IBAction)Viewfriend:(id)sender;
@end
