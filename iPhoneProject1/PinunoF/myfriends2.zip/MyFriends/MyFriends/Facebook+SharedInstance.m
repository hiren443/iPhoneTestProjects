//
//  Facebook+SharedInstance.m
//  MyFriends
//
//  Created by Pinuno Fuentes on 8/16/11.
//  Copyright 2011 Grapnel Tech Services LLC. All rights reserved.
//

#import "Facebook+SharedInstance.h"


@implementation Facebook (SharedInstance)

+ (Facebook *) sharedInstance;
{
    static Facebook *sInstance = nil;
    if (!sInstance) {
        sInstance = [[Facebook alloc] initWithAppId:@"145062165564860" andDelegate:nil];
    }
    return sInstance;
}

@end
