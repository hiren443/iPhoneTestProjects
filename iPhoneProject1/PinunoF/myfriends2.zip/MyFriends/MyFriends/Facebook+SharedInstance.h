//
//  Facebook+SharedInstance.h
//  MyFriends
//
//  Created by Pinuno Fuentes on 8/16/11.
//  Copyright 2011 Grapnel Tech Services LLC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FBConnect.h"


@interface Facebook (SharedInstance)

+ (Facebook *) sharedInstance;

@end
