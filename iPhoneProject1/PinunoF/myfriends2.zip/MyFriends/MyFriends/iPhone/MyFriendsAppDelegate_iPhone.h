//
//  MyFriendsAppDelegate_iPhone.h
//  MyFriends
//
//  Created by Pinuno Fuentes on 8/16/11.
//  Copyright 2011 Grapnel Tech Services LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyFriendsAppDelegate.h"

@interface MyFriendsAppDelegate_iPhone : MyFriendsAppDelegate {
    
}

@end
