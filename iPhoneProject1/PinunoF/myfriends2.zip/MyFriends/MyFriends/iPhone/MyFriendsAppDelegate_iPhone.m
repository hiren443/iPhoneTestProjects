//
//  MyFriendsAppDelegate_iPhone.m
//  MyFriends
//
//  Created by Pinuno Fuentes on 8/16/11.
//  Copyright 2011 Grapnel Tech Services LLC. All rights reserved.
//

#import "MyFriendsAppDelegate_iPhone.h"

@implementation MyFriendsAppDelegate_iPhone

- (void)dealloc
{
	[super dealloc];
}

@end
