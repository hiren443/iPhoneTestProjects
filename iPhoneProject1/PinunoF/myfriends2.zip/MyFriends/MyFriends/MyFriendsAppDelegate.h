//
//  MyFriendsAppDelegate.h
//  MyFriends
//
//  Created by Pinuno Fuentes on 8/16/11.
//  Copyright 2011 Grapnel Tech Services LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyFriendsAppDelegate : NSObject <UIApplicationDelegate> {
    UINavigationController *mainNavigationController_;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
