//
//  FriendsListVC.h
//  MyFriends
//
//  Created by Pinuno Fuentes on 8/16/11.
//  Copyright 2011 Grapnel Tech Services LLC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Facebook+SharedInstance.h"


@interface FriendsListVC : UIViewController <UITableViewDelegate, UITableViewDataSource, FBRequestDelegate>{
    IBOutlet UITableView *tableView_;
    NSMutableArray *friendList_;
}

@property (nonatomic, retain) UITableView *tableView;

@end
