//
//  MyFriendsAppDelegate_iPad.m
//  MyFriends
//
//  Created by Pinuno Fuentes on 8/16/11.
//  Copyright 2011 Grapnel Tech Services LLC. All rights reserved.
//

#import "MyFriendsAppDelegate_iPad.h"

@implementation MyFriendsAppDelegate_iPad

- (void)dealloc
{
	[super dealloc];
}

@end
