//
//  MainVC.m
//  MyFriends
//
//  Created by Pinuno Fuentes on 8/16/11.
//  Copyright 2011 Grapnel Tech Services LLC. All rights reserved.
//

#import "MainVC.h"


@implementation MainVC

#pragma mark - Lifecycle

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.navigationItem.title = @"My Friends";
        
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        if ([defaults objectForKey:@"FBAccessTokenKey"] && [defaults objectForKey:@"FBExpirationDateKey"]) {
            [Facebook sharedInstance].accessToken = [defaults objectForKey:@"FBAccessTokenKey"];
            [Facebook sharedInstance].expirationDate = [defaults objectForKey:@"FBExpirationDateKey"];
        }
    }
    return self;
}

- (void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Action Methods

- (IBAction) viewFriendsButtonTapped:(id)sender
{
    // if already logged in
    if ([[Facebook sharedInstance] isSessionValid]) {
        FriendsListVC *friendsListVC = [[FriendsListVC alloc] initWithNibName:nil bundle:nil];
        [self.navigationController pushViewController:friendsListVC animated:YES];
        [friendsListVC release];
    }
    
    // if not logged in
    else{
        [[Facebook sharedInstance] setSessionDelegate:self];
        [[Facebook sharedInstance] authorize:[NSArray arrayWithObjects:@"offline_access", nil]];
    }
    
}

#pragma mark - FBSessionDelegate Methods

- (void)fbDidLogin
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:[[Facebook sharedInstance] accessToken] forKey:@"FBAccessTokenKey"];
    [defaults setObject:[[Facebook sharedInstance] expirationDate] forKey:@"FBExpirationDateKey"];
    [defaults synchronize];
    
    FriendsListVC *friendsListVC = [[FriendsListVC alloc] initWithNibName:nil bundle:nil];
    [self.navigationController pushViewController:friendsListVC animated:YES];
    [friendsListVC release];
}

- (void)fbDidNotLogin:(BOOL)cancelled
{
    if (cancelled) {
        UIAlertView *alertView = [[[UIAlertView alloc] initWithTitle:nil 
                                                             message:@"You need to login to facebook to use the app." 
                                                            delegate:nil 
                                                   cancelButtonTitle:@"Ok" 
                                                   otherButtonTitles:nil] autorelease];
        [alertView show];
    }else{
        UIAlertView *alertView = [[[UIAlertView alloc] initWithTitle:nil 
                                                             message:@"Ooops! You were not logged in to facebook. Please try again." 
                                                            delegate:nil 
                                                   cancelButtonTitle:@"Ok" 
                                                   otherButtonTitles:nil] autorelease];
        [alertView show];
    }
}

- (void)fbDidLogout
{}

@end
