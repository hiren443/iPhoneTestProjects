//
//  FirstPageViewController.h
//  DemoApp
//
//  Created by Awais Macbook on 8/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface FirstPageViewController : UIViewController {

}
-(IBAction)viewFriends;
@end
