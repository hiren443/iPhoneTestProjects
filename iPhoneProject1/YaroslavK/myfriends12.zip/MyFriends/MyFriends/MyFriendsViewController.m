//
//  MyFriendsViewController.m
//  MyFriends
//
//  Created by Snow Leopard User on 27/08/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MyFriendsViewController.h"

@implementation MyFriendsViewController

@synthesize facebook;
@synthesize tlistFriends;
@synthesize listData;

- (void)dealloc
{
    [facebook release];
    [listData release];
    [bviewFriends release];
    [tlistFriends release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
 
    facebook = [[Facebook alloc] initWithAppId:@"145062165564860" andDelegate:self];
    facebook.sessionDelegate = self;
    
    listData = [[NSMutableArray alloc] init];
    
    
        
    bviewFriends.hidden = NO;
    tlistFriends.hidden = YES;
    
    
    [super viewDidLoad];
}


- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}



- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (IBAction)bviewFriendsClicked{
    
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"FBAccessTokenKey"] 
        && [defaults objectForKey:@"FBExpirationDateKey"]) {
        facebook.accessToken = [defaults objectForKey:@"FBAccessTokenKey"];
        facebook.expirationDate = [defaults objectForKey:@"FBExpirationDateKey"];
    }
    
    if (![facebook isSessionValid]) {
        [facebook authorize:nil];
    }
    
    bviewFriends.hidden = YES;
    tlistFriends.hidden = NO;
    
    [facebook requestWithGraphPath:@"me/friends" andDelegate:self];
    
}

/**
 * when login success
 */
- (void)fbDidLogin {
    
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:[facebook accessToken] forKey:@"FBAccessTokenKey"];
    [defaults setObject:[facebook expirationDate] forKey:@"FBExpirationDateKey"];
    [defaults synchronize];
    
    bviewFriends.hidden = YES;
    tlistFriends.hidden = NO;
 
    [facebook requestWithGraphPath:@"me/friends" andDelegate:self];
}


/**
 * when fail login
 */
-(void)fbDidNotLogin:(BOOL)cancelled {
    NSLog(@"did not login");
}

/**
 * when logout
 */
- (void)fbDidLogout {
    bviewFriends.hidden = NO;
    tlistFriends.hidden = YES;
}



- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url {
    
    return [facebook handleOpenURL:url]; 
}



- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return [self.listData count];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UILabel *lbl = [[UILabel alloc] init];
    lbl.text = @" My Friends";
    
    return lbl;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	
	static NSString *SimpleTableIdentifier = @"SimpleTableIdentifier";
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier: SimpleTableIdentifier];
	if (cell == nil) { cell = [[[UITableViewCell alloc]
								initWithStyle:UITableViewCellStyleDefault reuseIdentifier:SimpleTableIdentifier] autorelease];
	}
	NSUInteger irow = [indexPath row];
    cell.textLabel.text = [listData objectAtIndex:irow];
    return cell;
	
}


- (void)request:(FBRequest *)request didLoad:(id)result {
    [listData removeAllObjects];
    
    if ([result isKindOfClass:[NSArray class]]) {
        result = [result objectAtIndex:0];
    }
    if ([result objectForKey:@"data"]){
        NSArray *friends = [result objectForKey:@"data"];
		for (NSDictionary* myfriend in friends) {
            NSString *myfriendName = [myfriend objectForKey:@"name"];
            [listData addObject:myfriendName];
        }
       
    }
    
    [tlistFriends reloadData];
};



/**
 * Called when an error prevents the Facebook API request from completing
 * successfully.
 */
- (void)request:(FBRequest *)request didFailWithError:(NSError *)error {
    NSLog(@"request fail");
};



@end
