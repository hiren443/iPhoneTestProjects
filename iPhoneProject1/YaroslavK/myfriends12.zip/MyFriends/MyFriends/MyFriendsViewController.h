//
//  MyFriendsViewController.h
//  MyFriends
//
//  Created by Snow Leopard User on 27/08/2011.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FBConnect.h"

@interface MyFriendsViewController : UIViewController<UIApplicationDelegate,FBSessionDelegate, FBRequestDelegate>{
    
    Facebook *facebook;
    IBOutlet UIButton *bviewFriends;
    IBOutlet UITableView *tlistFriends;
    NSMutableArray *listData;
    
}

@property (nonatomic, retain) Facebook *facebook;
@property (nonatomic, retain) UITableView *tlistFriends;
@property (nonatomic, retain) NSMutableArray *listData;

- (IBAction)bviewFriendsClicked;

@end
