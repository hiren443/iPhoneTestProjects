//
//  MyFriendsViewController.m
//  MyFriends
//
//  Created by Newtok Technologies Pvt Ltd on 25/08/11.
//  Copyright 2011 Newtok Technologies Pvt Ltd. All rights reserved.
//
#define ACCESS_TOKEN_KEY @"fb_access_token"
#define EXPIRATION_DATE_KEY @"fb_expiration_date"

#import "MyFriendsViewController.h"
#import "FriendsList.h"
@implementation MyFriendsViewController
@synthesize facebook;
@synthesize viewFriends;
- (void)dealloc
{
    [viewFriends release];
    [facebook release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad
{
    [super viewDidLoad];
    [loadingLabel setHidden:YES];
    
    //Give the facebook appId to Facebook Class instance (facebook)
    facebook=[[Facebook alloc]initWithAppId:@"145062165564860" andDelegate:self];
}
//This event is used for Login to facebook login page (Single Sign-On)
-(IBAction)viewFriendsClick:(id)sender
{
    
    loadingAct=[[UIActivityIndicatorView alloc]initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
    [loadingAct setFrame:CGRectMake(140, 160, 32, 32)];
    [self.view addSubview:loadingAct];
    [loadingAct startAnimating];
    NSArray *permissions =  [[NSArray arrayWithObjects:
                              @"email", @"read_stream", @"user_birthday", 
                              @"user_about_me", @"publish_stream", @"offline_access", nil] retain];
    //Authorize the login user
    [facebook authorize:permissions localAppId:@"newtok"];
    [permissions release];
    [viewFriends setHidden:YES];
    [loadingLabel setHidden:NO];
    [MyFriendNavBar setHidden:YES];
   
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
- (void)fbDidLogin 
{
    // Store the value in the NSUserDefaults
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:facebook.accessToken forKey:ACCESS_TOKEN_KEY];
    [defaults setObject:facebook.expirationDate forKey:EXPIRATION_DATE_KEY];
    [defaults synchronize];
    // Access the logged-in user's friends
    [facebook requestWithGraphPath:@"me/friends" andDelegate:self];
   
    
}

-(void)fbDidNotLogin:(BOOL)cancelled {
	NSLog(@"did not login");
}

//Acessed friends list add to array for display purpose 
- (void)request:(FBRequest *)request didLoad:(id)result 
{
    //listArray is used for hold the friends list
    NSMutableArray *listArray=[[NSMutableArray alloc]initWithCapacity:[result count]];
    result=[result objectForKey:@"data"];
      if ([result isKindOfClass:[NSArray class]]) 
          for(int i=0;i<[result count];i++)
            {            
             NSDictionary *result2=[result objectAtIndex:i];
             NSString *result1=[result2 objectForKey:@"name"];
            [listArray addObject:result1];
            }
    //sortedArray is used for sort the friends list 
    NSArray *sortedArray;
    sortedArray=[listArray sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
    [listArray release];
    //Pass the array value to table view
    FriendsList *friendList=[[FriendsList alloc]initWithNibName:@"FriendsList" bundle:nil];
    friendList.friendsListArray=[[NSMutableArray alloc]initWithArray:sortedArray];
    [loadingAct stopAnimating];
    [loadingAct release];
    [self .view addSubview:friendList.view];
    
    }

- (void)request:(FBRequest *)request didFailWithError:(NSError *)error {
    NSLog(@"Failed with error: %@", [error localizedDescription]);
}



@end
