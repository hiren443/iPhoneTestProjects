//
//  MyFriendsViewController.h
//  MyFriends
//
//  Created by Newtok Technologies Pvt Ltd on 25/08/11.
//  Copyright 2011 Newtok Technologies Pvt Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Facebook.h"
@interface MyFriendsViewController : UIViewController<FBRequestDelegate,FBSessionDelegate> {
    Facebook *facebook; 
    IBOutlet UIButton *viewFriends;
    IBOutlet UILabel *loadingLabel;
    IBOutlet UINavigationBar *MyFriendNavBar;
    UIActivityIndicatorView *loadingAct;
}
@property(nonatomic,retain)Facebook *facebook;
@property(nonatomic,retain)IBOutlet UIButton *viewFriends;
-(IBAction)viewFriendsClick:(id)sender;
@end
