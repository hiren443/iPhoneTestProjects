//
//  MyFriendsAppDelegate.h
//  MyFriends
//
//  Created by Newtok Technologies Pvt Ltd on 25/08/11.
//  Copyright 2011 Newtok Technologies Pvt Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MyFriendsViewController;

@interface MyFriendsAppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet MyFriendsViewController *viewController;

@end
