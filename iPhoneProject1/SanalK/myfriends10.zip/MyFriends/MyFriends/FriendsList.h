//
//  FriendsList.h
//  MyFriends
//
//  Created by Newtok Technologies Pvt Ltd on 25/08/11.
//  Copyright 2011 Newtok Technologies Pvt Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface FriendsList : UITableViewController {
    NSMutableArray *friendsListArray;
    
}
//This array property is used for get the friends list from MyFriendViewController class 
@property(nonatomic,retain)NSMutableArray *friendsListArray;

@end