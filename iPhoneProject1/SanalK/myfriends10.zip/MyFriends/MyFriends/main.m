//
//  main.m
//  MyFriends
//
//  Created by Newtok Technologies Pvt Ltd on 25/08/11.
//  Copyright 2011 Newtok Technologies Pvt Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
