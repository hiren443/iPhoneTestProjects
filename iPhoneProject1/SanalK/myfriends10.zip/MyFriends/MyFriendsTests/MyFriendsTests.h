//
//  MyFriendsTests.h
//  MyFriendsTests
//
//  Created by Newtok Technologies Pvt Ltd on 25/08/11.
//  Copyright 2011 Newtok Technologies Pvt Ltd. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface MyFriendsTests : SenTestCase {
@private
    
}

@end
