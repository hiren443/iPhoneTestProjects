
#import "SessionDelegate.h"
#import "Lumberjack.h"

#ifdef LOG_CONFIGURATION_DEBUG
static const int ddLogLevel = LOG_LEVEL_VERBOSE;
#else
static const int ddLogLevel = LOG_LEVEL_WARN;
#endif

@implementation SessionDelegate

@synthesize facebook;
@synthesize accessTokenKey;
@synthesize expirationKey;
@synthesize loginCancelledNotificationKey;
@synthesize loginSucceedNotificationKey;


- (void) dealloc {
  [facebook release];
  [accessTokenKey release];
  [expirationKey release];
  [loginCancelledNotificationKey release];
  [loginSucceedNotificationKey release];
  [super dealloc];
}

- (id) initWithAccessTokenKey:(NSString *) anAccessTokenKey
                expirationKey:(NSString *) anExpirationKey 
            loginCancelledKey:(NSString *) aCancelKey
            loginSucceededKey:(NSString *) aSucceededKey {
  self = [super init];
  if (self) {
    self.accessTokenKey = anAccessTokenKey;
    self.expirationKey = anExpirationKey;
    self.loginCancelledNotificationKey = aCancelKey;
    self.loginSucceedNotificationKey = aSucceededKey;
  }
  return self;
}


/**
 * Called when the user dismissed the dialog without logging in.
 */
- (void) fbDidLogout:(BOOL) cancelled {
  DDLogDebug(@"did logout with cancelled = %d", cancelled);
  [[NSNotificationCenter defaultCenter] postNotificationName:self.loginCancelledNotificationKey object:nil];
 }

/**
 * Called when the user successfully logged in.
 */
- (void) fbDidLogin {
  DDLogDebug(@"fb did login");
  NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
  [defaults setObject:[facebook accessToken] forKey:self.accessTokenKey];
  [defaults setObject:[facebook expirationDate] forKey:self.expirationKey];
  [defaults synchronize];
  [[NSNotificationCenter defaultCenter] postNotificationName:self.loginSucceedNotificationKey object:nil];
}


/**
 * Called when the user logged out.
 */
- (void)fbDidLogout {
  DDLogDebug(@"did log out - nothing to do");
}


- (NSString *) description {
  NSString *result = [NSString stringWithFormat:@"<#%@ >", [self class]];
  return result;
}





@end
