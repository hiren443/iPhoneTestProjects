#import <UIKit/UIKit.h>

@class MyFriendsViewController;

@interface MyFriendsAppDelegate : NSObject <UIApplicationDelegate>

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet MyFriendsViewController *viewController;

@end
