#import <UIKit/UIKit.h>
#import "ColorfulButton.h"
#import "FBConnect.h"
#import "FriendsViewController.h"


@interface MyFriendsViewController : UIViewController <FBRequestDelegate>

@property (nonatomic, retain) IBOutlet ColorfulButton *viewFriendsButton;
@property (nonatomic, retain) Facebook *facebook;
@property (nonatomic, assign) BOOL didTryToRequestFriends;
@property (nonatomic, retain) FriendsViewController *friendsTableVC;
@property (nonatomic, retain) IBOutlet UIActivityIndicatorView *friendsRequestProgress;

- (void) configureViewFriendsButton;

- (IBAction) viewFriendsButtonTouched:(id)sender;

- (void) makeFriendsRequest;
  
- (void) loginDialogDidComplete:(NSNotification *) aNotification;

- (void) newFriendImageAvailable:(NSNotification *) aNotification;

@end
