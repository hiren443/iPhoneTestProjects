
#import "ImageFetchOperation.h"
#import "Lumberjack.h"

#ifdef LOG_CONFIGURATION_DEBUG
static const int ddLogLevel = LOG_LEVEL_VERBOSE;
#else
static const int ddLogLevel = LOG_LEVEL_WARN;
#endif

@implementation ImageFetchOperation

@synthesize friend;
@synthesize imageAvailableNoteKey;
@synthesize friendKey;

- (void) dealloc {
  [friend release];
  [imageAvailableNoteKey release];
  [friendKey release];
  [super dealloc];
}
// Disallow the normal default initializer for instances
- (id)init {
  [self doesNotRecognizeSelector:_cmd];
  return nil;
}

- (id) initWithFriend:(Friend *) aFriend  
    imageReadyNoteKey:(NSString *)aNotificationKey 
            friendKey:(NSString *)aFriendKey {
  self = [super init];
  if (self) {
    // Initialization code here.
    self.friend = aFriend;
    self.imageAvailableNoteKey = aNotificationKey;
    self.friendKey = aFriendKey;
  }
  return self;
}

- (void) main {
 NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
  if (![self isCancelled]) {
    NSURL *url = self.friend.imageURL;
    UIImage *image = [[UIImage alloc] initWithData:[NSData dataWithContentsOfURL:url]];
    self.friend.picture = image;
    if (image != nil) {
      NSDictionary *userInfo = [NSDictionary dictionaryWithObject:self.friend forKey:self.friendKey];
      [[NSNotificationCenter defaultCenter] postNotificationName:self.imageAvailableNoteKey
                                                          object:nil
                                                        userInfo:userInfo];
    }
    [image release];
  }
  [pool release];
}

@end
