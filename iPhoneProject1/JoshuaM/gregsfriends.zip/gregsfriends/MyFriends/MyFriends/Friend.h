
#import <Foundation/Foundation.h>

@interface Friend : NSObject {
    
}

@property (nonatomic, copy) NSString *name;
@property (nonatomic, retain) UIImage *picture;
@property (nonatomic, retain) NSURL *imageURL;

- (id) initWithName:(NSString *) aName 
            picture:(UIImage *) aPicture
           imageURL:(NSURL *) anImageUrl;

@end
