//
//  FriendsViewController.m
//  MyFriends
//
//  Created by Joshua Moody on 8/18/11.
//  Copyright 2011 The Little Joy Software Company. All rights reserved.
//

#import "FriendsViewController.h"
#import "Friend.h"

#ifdef LOG_CONFIGURATION_DEBUG
static const int ddLogLevel = LOG_LEVEL_VERBOSE;
#else
static const int ddLogLevel = LOG_LEVEL_WARN;
#endif

@implementation FriendsViewController

@synthesize tableView;
@synthesize friends;
@synthesize defaultPicture;

- (void) dealloc {
  [tableView release];
  [friends release];
  [defaultPicture release];
  [super dealloc];
}

- (id)init {
  self = [super init];
  if (self != nil) {
    // Custom initialization
    self.friends = [NSMutableArray array];
    self.defaultPicture = [UIImage imageNamed:@"Icon-72.png"];
  }
  return self;
}

- (void)didReceiveMemoryWarning {
  // Releases the view if it doesn't have a superview.
  [super didReceiveMemoryWarning];
  
  // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
   UIView *contentView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
   contentView.autoresizesSubviews = YES;
   contentView.autoresizingMask = (UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight);
   contentView.backgroundColor = [UIColor clearColor];
   
   [self setView:contentView];
   [contentView release];
   
   self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 60, 320, 440) style:UITableViewStylePlain];
   [self.tableView setAutoresizesSubviews:YES];
   [self.tableView setAutoresizingMask:(UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight)];
   
   
   [self.tableView setDataSource:self];
   [self.tableView setDelegate:self];
   
   [[self view] addSubview:tableView];
}

- (void) awakeFromNib {
  DDLogDebug(@"waking from nib");
}

- (void)viewDidLoad {
  [super viewDidLoad];
  // Do any additional setup after loading the view from its nib.
  DDLogDebug(@"view did load");
}

- (void)viewDidUnload {
  [super viewDidUnload];
  // Release any retained subviews of the main view.
  // e.g. self.myOutlet = nil;
  DDLogDebug(@"view did unload");
}

- (void) viewWillAppear:(BOOL)animated {
  [super viewWillAppear:animated];
  DDLogDebug(@"view will appear");
}

#pragma mark UITableViewDataSource

- (UITableViewCell *)tableView:(UITableView *) tableView cellForRowAtIndexPath:(NSIndexPath *) indexPath {
  UITableViewCell *cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                                  reuseIdentifier:@"UITableViewCell"] autorelease];
  
  Friend *friend = [self.friends objectAtIndex:[indexPath row]];
  
  cell.textLabel.text = friend.name;
  UIImage *image = friend.picture;
  if (image == nil) {
    image = self.defaultPicture;
  }
  cell.imageView.image = image;
  
  return cell;
}

- (NSInteger)tableView:(UITableView *) tableView numberOfRowsInSection:(NSInteger) section {
  return [self.friends count];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
