/*
 Cribbed from http://www.cimgf.com/2010/01/28/fun-with-uibuttons-and-core-animation-layers/
 
 Many thanks.
 */
#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>
@interface ColorfulButton : UIButton {
    
}

@property (nonatomic, retain) UIColor *_highColor;
@property (nonatomic, retain) UIColor *_lowColor;
@property (nonatomic, retain) CAGradientLayer *gradientLayer;

- (void) setHighColor:(UIColor *) aColor;
- (void) setLowColor:(UIColor *) aColor;

@end
