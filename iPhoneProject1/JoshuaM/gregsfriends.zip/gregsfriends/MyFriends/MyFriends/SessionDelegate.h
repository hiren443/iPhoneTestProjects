
#import <Foundation/Foundation.h>
#import "FBConnect.h"

@interface SessionDelegate : NSObject <FBSessionDelegate> {
    
}

@property (nonatomic, retain) Facebook *facebook;
@property (nonatomic, copy) NSString *accessTokenKey;
@property (nonatomic, copy) NSString *expirationKey;
@property (nonatomic, copy) NSString *loginCancelledNotificationKey;
@property (nonatomic, copy) NSString *loginSucceedNotificationKey;

- (id) initWithAccessTokenKey:(NSString *) anAccessTokenKey
          expirationKey:(NSString *) anExpirationKey
            loginCancelledKey:(NSString *) aCancelKey
            loginSucceededKey:(NSString *) aSucceededKey;

@end
