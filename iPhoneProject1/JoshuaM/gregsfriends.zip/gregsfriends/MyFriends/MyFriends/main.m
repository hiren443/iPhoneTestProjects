//
//  main.m
//  MyFriends
//
//  Created by Joshua Moody on 8/17/11.
//  Copyright 2011 The Little Joy Software Company. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Lumberjack.h"

int main(int argc, char *argv[]) {
  NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
  
  LjsDefaultFormatter *formatter = [[LjsDefaultFormatter alloc] init];
  DDTTYLogger *tty = [DDTTYLogger sharedInstance];
  [tty setLogFormatter:formatter];
  [DDLog addLogger:tty];
  
  /*
  DDFileLogger *fileLogger = [[DDFileLogger alloc] init];
  [fileLogger setLogFormatter:formatter];
  fileLogger.logFileManager.maximumNumberOfLogFiles = 1;
  [DDLog addLogger:fileLogger];
   */
  
  int retVal = UIApplicationMain(argc, argv, nil, nil);
  [pool release];
  return retVal;
}
