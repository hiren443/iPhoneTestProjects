//
//  FriendsViewController.h
//  MyFriends
//
//  Created by Joshua Moody on 8/18/11.
//  Copyright 2011 The Little Joy Software Company. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FriendsViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, retain) UITableView *tableView;
@property (nonatomic, retain) NSMutableArray *friends;
@property (nonatomic, retain) UIImage *defaultPicture;

@end
