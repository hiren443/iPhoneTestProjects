
#import <Foundation/Foundation.h>
#import "Friend.h"
@interface ImageFetchOperation : NSOperation {
    
}

@property (nonatomic, retain) Friend *friend;
@property (nonatomic, copy) NSString *imageAvailableNoteKey;
@property (nonatomic, copy) NSString *friendKey;


- (id) initWithFriend:(Friend *) aFriend 
    imageReadyNoteKey:(NSString *) aNotificationKey
            friendKey:(NSString *) aFriendKey;

@end
