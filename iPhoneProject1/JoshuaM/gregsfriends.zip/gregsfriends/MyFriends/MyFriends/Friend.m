
#import "Friend.h"
#import "Lumberjack.h"

#ifdef LOG_CONFIGURATION_DEBUG
static const int ddLogLevel = LOG_LEVEL_VERBOSE;
#else
static const int ddLogLevel = LOG_LEVEL_WARN;
#endif

@implementation Friend

@synthesize name;
@synthesize picture;
@synthesize imageURL;

- (void) dealloc {
  [name release];
  [picture release];
  [imageURL release];
  [super dealloc];
}


- (id) initWithName:(NSString *) aName picture:(UIImage *) aPicture imageURL:(NSURL *)anImageUrl {
  
  self = [super init];
  if (self) {
    // Initialization code here.
    self.name = aName;
    self.picture = aPicture;
    self.imageURL = anImageUrl;
  }
  return self;
}


- (NSString *) description {
  NSString *result = [NSString stringWithFormat:@"<#%@ >", [self class]];
  return result;
}


@end
