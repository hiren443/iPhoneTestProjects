#import "MyFriendsViewController.h"
#import "SessionDelegate.h"
#import "Friend.h"
#import "ImageFetchOperation.h"

#ifdef LOG_CONFIGURATION_DEBUG
static const int ddLogLevel = LOG_LEVEL_VERBOSE;
#else
static const int ddLogLevel = LOG_LEVEL_WARN;
#endif

static NSString *ComLjsAppId = @"145062165564860";

//static NSString *ComLjsAppSecret = @"09d5ff4260a342ea3012cf2888e47d4e";
//static NSString *ComLjsAccessToken = @"145062165564860|2.AQDKoREPlrzAZm35.3600.1313452800.0-205600|9UjsqAZlYIOUNBrDp463xOalXZA";

static NSString *ComLjsFBAccessTokenKey = @"FBAccessTokenKey";
static NSString *ComLjsFBExpirationDateKey = @"FBExpirationDateKey";

static NSString *ComLjsLoginCancelledNotificationKey = @"com.littlejoysoftware.MyFriends.loginCancelled";
static NSString *ComLjsLoginSucceededNotificationKey = @"com.littlejoysoftware.MyFriends.loginSucceeded";

static NSString *ComLjsImageAvailableNotificationKey = @"com.littlejoysoftware.MyFriends.imageAvaliable";
static NSString *ComLjsImageAvailableNotificationFriendKey = @"com.littlejoysoftware.MyFrineds.imageAvailable.friendKey";

static NSString *ComLjsFriendsRequestFields = @"name,id,picture";
static NSString *ComLjsFriendsRequestFieldsKey = @"fields";
static NSString *ComLjsFriendsRequestPath = @"me/friends";

static NSString *ComLjsFriendsRequestReplyNameKey = @"name";
static NSString *ComLjsFriendsRequestReplyPictureKey = @"picture";


@implementation MyFriendsViewController 

@synthesize viewFriendsButton;
@synthesize facebook;
@synthesize didTryToRequestFriends;
@synthesize friendsTableVC;
@synthesize friendsRequestProgress;


- (void) dealloc {
  [viewFriendsButton release];
  [facebook release];
  [[NSNotificationCenter defaultCenter] removeObserver:self];
  [friendsTableVC release];
  [friendsRequestProgress release];
  [super dealloc];
}

- (void)didReceiveMemoryWarning {
  // Releases the view if it doesn't have a superview.
  [super didReceiveMemoryWarning];
  // Release any cached data, images, etc that aren't in use.
}

#pragma mark  View lifecycle

- (void) awakeFromNib {
  DDLogDebug(@"waking from nib");
  SessionDelegate *sessionDelegate = [[SessionDelegate alloc] initWithAccessTokenKey:ComLjsFBAccessTokenKey
                                                                       expirationKey:ComLjsFBExpirationDateKey
                                                                   loginCancelledKey:ComLjsLoginCancelledNotificationKey
                                                                   loginSucceededKey:ComLjsLoginSucceededNotificationKey];
  
  self.facebook = [[[Facebook alloc] initWithAppId:ComLjsAppId andDelegate:sessionDelegate] autorelease];
  // wonky
  sessionDelegate.facebook = self.facebook;
  
  NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
  if ([defaults objectForKey:ComLjsFBAccessTokenKey] && 
      [defaults objectForKey:ComLjsFBExpirationDateKey]) {
    facebook.accessToken = [defaults objectForKey:ComLjsFBAccessTokenKey];
    facebook.expirationDate = [defaults objectForKey:ComLjsFBExpirationDateKey];
  }
 
  [[NSNotificationCenter defaultCenter] addObserver:self
                                           selector:@selector(loginDialogDidComplete:) 
                                               name:ComLjsLoginCancelledNotificationKey
                                             object:nil];
  
  [[NSNotificationCenter defaultCenter] addObserver:self
                                           selector:@selector(loginDialogDidComplete:) 
                                               name:ComLjsLoginSucceededNotificationKey
                                             object:nil];

  [[NSNotificationCenter defaultCenter] addObserver:self
                                           selector:@selector(newFriendImageAvailable:) 
                                               name:ComLjsImageAvailableNotificationKey
                                             object:nil];

  self.didTryToRequestFriends = NO;
  
  self.friendsRequestProgress.hidesWhenStopped = YES;
  friendsRequestProgress.hidden = YES;
}


- (void)viewDidLoad {
  [super viewDidLoad];
  DDLogDebug(@"view did load");
  [self configureViewFriendsButton];
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


# pragma mark Facebook Request Delegate


/**
 * Called just before the request is sent to the server.
 */
- (void)requestLoading:(FBRequest *)request {
  DDLogDebug(@"request is loading - details: (%@ - %@) : %@", request.url, 
             request.httpMethod, request.params);
}

/**
 * Called when the server responds and begins to send back data.
 */
- (void)request:(FBRequest *)request didReceiveResponse:(NSURLResponse *)response {
  DDLogDebug(@"request is receiving response - details: (%@ - %@) : %@", request.url, 
             request.httpMethod, request.params);
}

/**
 * Called when an error prevents the request from completing successfully.
 */
- (void)request:(FBRequest *)request didFailWithError:(NSError *)error {
  DDLogDebug(@"some request failed");
  if ([self.facebook isSessionValid]) {
    DDLogDebug(@"we have a valid session, but a request failed");
  } else {
    DDLogDebug(@"we do not have a valid session, so we expect the request to fail");
  }
  DDLogError(@"Error details: (%d) %@ - %@", [error code], [error localizedDescription], 
             [error userInfo]);
  
  DDLogError(@"Request details: (%@ - %@) : %@", request.url, 
             request.httpMethod, request.params);
  
}

/**
 * Called when a request returns and its response has been parsed into
 * an object.
 *
 * The resulting object may be a dictionary, an array, a string, or a number,
 * depending on thee format of the API response.
 */
- (void)request:(FBRequest *)request didLoad:(id)result {
  DDLogDebug(@"request finished loading: details: (%@ - %@) : %@", request.url, 
             request.httpMethod, request.params);
	if ([result isKindOfClass:[NSArray class]]) {
		result = [result objectAtIndex:0];
	}

  NSArray *friendsArray = [result objectForKey:@"data"];
  DDLogDebug(@"found %d friends", [friendsArray count]);

  NSMutableArray *dataSource = [NSMutableArray arrayWithCapacity:[friendsArray count]];
  for (NSDictionary *dict in friendsArray) {
    NSString *name = [dict objectForKey:ComLjsFriendsRequestReplyNameKey];
    NSString *pictureUrl = [dict objectForKey:ComLjsFriendsRequestReplyPictureKey];    
    NSURL *url = [NSURL URLWithString:pictureUrl];
    Friend *friend = [[Friend alloc] initWithName:name picture:nil imageURL:url];
    ImageFetchOperation *fetch = [[ImageFetchOperation alloc] initWithFriend:friend 
                                                           imageReadyNoteKey:ComLjsImageAvailableNotificationKey
                                                                   friendKey:ComLjsImageAvailableNotificationFriendKey];
    [[NSOperationQueue currentQueue] addOperation:fetch];
    [dataSource addObject:friend];
    [friend release];
    [fetch release];
  }
 
  if (self.friendsTableVC == nil) {
    self.friendsTableVC = [[[FriendsViewController alloc] init] autorelease];
  }
  
  self.friendsTableVC.friends = dataSource;
  [self.view addSubview:self.friendsTableVC.view];
  [self.friendsTableVC loadView];
  [self.friendsTableVC.tableView reloadData];
  [self.friendsRequestProgress stopAnimating];
  friendsRequestProgress.hidden = YES;
}

/**
 * Called when a request returns a response.
 *
 * The result object is the raw response from the server of type NSData
 */
- (void)request:(FBRequest *)request didLoadRawResponse:(NSData *)data {
  DDLogDebug(@"request loaded raw response: details: (%@ - %@) : %@", request.url, 
             request.httpMethod, request.params);
}

#pragma mark Button Actions

- (IBAction) viewFriendsButtonTouched:(id)sender {
  DDLogDebug(@"view friends button touched");
  BOOL facebookSessionValid = [self.facebook isSessionValid];
  DDLogDebug(@"is facebook session valid: %d", facebookSessionValid);
  
  if (facebookSessionValid == NO) {
    NSArray *permissions = [NSArray arrayWithObjects:@"", nil];
    [self.facebook authorize:permissions localAppId:ComLjsAppId];
 
  }

  if ([self.facebook isSessionValid]) {
    DDLogDebug(@"we have a valid session, so make the request");
    [self makeFriendsRequest];
  } else {
    DDLogDebug(@"we do not have a valid session - we wait for the login dialog to finish");
  }
}

#pragma mark Make Friends Request

- (void) makeFriendsRequest {
  
  self.friendsRequestProgress.hidden = NO;
  [self.friendsRequestProgress startAnimating];
  
  NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:
                          ComLjsFriendsRequestFields, ComLjsFriendsRequestFieldsKey, nil];
  [facebook requestWithGraphPath:ComLjsFriendsRequestPath
                       andParams:[NSMutableDictionary dictionaryWithDictionary:params]
                     andDelegate:self];
  self.didTryToRequestFriends = YES;
}


#pragma mark Notification Observer Selectors

- (void) loginDialogDidComplete:(NSNotification *) aNotification {
  DDLogVerbose(@"login did complete");
  if (self.didTryToRequestFriends == YES) {
    DDLogDebug(@"Already tried friends request - ignoring this call");
  } else if ([self.facebook isSessionValid]) {
    DDLogDebug(@"we have a valid session, so make the request");
    [self makeFriendsRequest];
  } else {
    DDLogDebug(@"we do not have a valid session - maybe we should post an alert.");
  }
}


// do not force the user to have to scroll to update pictures
- (void) newFriendImageAvailable:(NSNotification *) aNotification {
  NSDictionary *userInfo = [aNotification userInfo];
  Friend *friend = [userInfo objectForKey:ComLjsImageAvailableNotificationFriendKey];
  
  FriendsViewController *fvc = self.friendsTableVC;
  UITableView *tableView = fvc.tableView;
  NSArray *dataSource = fvc.friends;
  
  if (fvc != nil && tableView != nil && dataSource != nil) {
    NSUInteger index = [dataSource indexOfObject:friend];
    
    NSArray *indexPaths = [tableView indexPathsForVisibleRows];
    if (indexPaths != nil && [indexPaths count] > 1) { 
      NSIndexPath *first = [indexPaths objectAtIndex:0];
      NSUInteger minCellIndex = [first indexAtPosition:1];
      NSIndexPath *last = [indexPaths lastObject];
      NSUInteger maxCellIndex = [last indexAtPosition:1];
      if (index >= minCellIndex && index <= maxCellIndex) {
        [tableView reloadData];
      }
    }
   }
}


#pragma mark Configure Buttons

- (void) configureViewFriendsButton {
  [self.viewFriendsButton.layer setCornerRadius:8.0f];
  [self.viewFriendsButton.layer setMasksToBounds:YES];
  
  UIColor *yellow = [UIColor colorWithRed:243.0/255.0 green:235.0/255.0 blue:91.0/255.0
                                    alpha:1.0];
  [self.viewFriendsButton setHighColor:yellow];
  [self.viewFriendsButton setLowColor:[UIColor blueColor]];
  UIColor *green = [UIColor colorWithRed:45.0/255.0 green:91.0/255.0 blue:125.0/255.0
                                   alpha:1.0];
  [self.viewFriendsButton setTitleColor:green 
                               forState:UIControlStateHighlighted];  
}

#pragma mark Orientations
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end


