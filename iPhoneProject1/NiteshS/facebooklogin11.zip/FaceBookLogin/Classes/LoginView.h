//
//  LoginView.h
//  FaceBookLogin
//
//  Created by ampheetech on 8/26/11.
//  Copyright 2011 ampheetech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"
#import "FbGraph.h"
#define kname 1
#define kdesc 2

@interface LoginView : UIViewController<UIWebViewDelegate>
{
	FbGraph *fbGraph;
	NSString *feedPostId;
	NSArray *friends;
	NSMutableArray *list;
	NSMutableArray *idList;
	IBOutlet UITableView *table;
	MainViewController *mainView;
	NSMutableArray *dataArray;
	
}
@property (nonatomic,retain)	NSMutableArray *dataArray;
@property (nonatomic,retain)MainViewController *mainView;
@property (nonatomic,retain)	NSMutableArray *idList;
@property (nonatomic,retain)	IBOutlet UITableView *table;
@property (nonatomic,retain)NSMutableArray *list;
@property(nonatomic,retain)NSArray *friends;
@property (nonatomic, retain) FbGraph *fbGraph;
@property (nonatomic, retain) NSString *feedPostId;
@end
