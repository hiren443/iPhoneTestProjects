//
//  LoginView.m
//  FaceBookLogin
//
//  Created by ampheetech on 8/26/11.
//  Copyright 2011 ampheetech. All rights reserved.
//

#import "LoginView.h"
#import "FbGraphFile.h"
#import "CJSONDeserializer.h"
@implementation LoginView
@synthesize friends;
@synthesize fbGraph;
@synthesize feedPostId;
@synthesize list;
@synthesize table,idList;
@synthesize mainView,dataArray;
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/
- (void)viewDidAppear:(BOOL)animated {
	
	/*Facebook Application ID*/
	NSString *client_id = @"130902823636657";
	
	//alloc and initalize our FbGraph instance
	self.fbGraph = [[FbGraph alloc] initWithFbClientID:client_id];
	
	//begin the authentication process.....
	[fbGraph authenticateUserWithCallbackObject:self andSelector:@selector(fbGraphCallback:) 
						 andExtendedPermissions:@"user_photos,user_videos,publish_stream,offline_access,user_checkins,friends_checkins"];
	
}

- (void)fbGraphCallback:(id)sender {
	
	if ( (fbGraph.accessToken == nil) || ([fbGraph.accessToken length] == 0) ) {
		
		NSLog(@"You pressed the 'cancel' or 'Dont Allow' button, you are NOT logged into Facebook...I require you to be logged in & approve access before you can do anything useful....");
		
		//restart the authentication process.....
		[fbGraph authenticateUserWithCallbackObject:self andSelector:@selector(fbGraphCallback:) 
							 andExtendedPermissions:@"user_photos,user_videos,publish_stream,offline_access,user_checkins,friends_checkins"];
		
	} else {
		/*
		//pop a message letting them know most of the info will be dumped in the log
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Note" message:@"For the simplest code, I've written all output to the 'Debugger Console'." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
		[alert show];
		[alert release];
		
		NSLog(@"------------>CONGRATULATIONS<------------, You're logged into Facebook...  Your oAuth token is:  %@", fbGraph.accessToken);
		*/
		list=[[NSMutableArray alloc]init];
		idList =[[NSMutableArray alloc]init];
		FbGraphResponse *fb_graph_response = [fbGraph doGraphGet:@"me/friends" withGetVars:nil];
		NSLog(@"getMeFriendsButtonPressed:  %@", fb_graph_response.htmlResponse);
		//	NSString *jsonreturn = [[NSString alloc] initWithContentsOfURL:fb_graph_response.htmlResponse];
		
		//	NSLog(jsonreturn); // Look at the console and you can see what the restults are
		
		NSData *jsonData = [fb_graph_response.htmlResponse dataUsingEncoding:NSUTF32BigEndianStringEncoding];
		NSError *error = nil;
		
		// In "real" code you should surround this with try and catch
		NSDictionary * dict = [[[CJSONDeserializer deserializer] deserializeAsDictionary:jsonData error:&error] retain];
		if (dict)
		{
			friends = [dict objectForKey:@"data"];
		}
		dataArray=[[NSMutableArray alloc]init];
		for(int i=0 ;i<[friends count];i++)
		{
			NSDictionary *dict1 = [friends objectAtIndex:i];
			NSLog(@"Array :%@",[dict1 objectForKey:@"name"]);
			NSLog(@"Array :%@",[dict1 objectForKey:@"id"]);
			[list addObject:[dict1 objectForKey:@"name"]];
			[idList addObject:[dict1 objectForKey:@"id"]];
			
			NSString *imgStr=[[NSString alloc]initWithFormat:@"https://graph.facebook.com/%@/picture",[idList objectAtIndex:i]];
			NSLog(@"image Url :%@",imgStr);
			NSURL *url = [NSURL URLWithString:imgStr];
			
			NSData *urlData = [NSData dataWithContentsOfURL:url];
			[dataArray addObject:urlData];
		}
		
		
		
	}
	UIBarButtonItem *barButton=[[UIBarButtonItem alloc]initWithTitle:@"Sign Out" style:UIBarButtonItemStyleBordered target:self action:@selector(signout)];
	self.navigationItem.leftBarButtonItem=barButton;
	[table	reloadData];
	
}
-(void)signout
{
	[fbGraph signOutUser];
	[mainView FirstViewCall];
}
/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}
- (NSInteger)tableView:(UITableView *)tableView 
 numberOfRowsInSection:(NSInteger)section { 
    return [self.list count]; 
} 
- (UITableViewCell *)tableView:(UITableView *)tableView 
		 cellForRowAtIndexPath:(NSIndexPath *)indexPath { 
    static NSString *SimpleTableIdentifier = @"SimpleTableIdentifier"; 
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier: 
							 SimpleTableIdentifier]; 
    if (cell == nil) { 
        cell = [[[UITableViewCell alloc] 
				 initWithStyle:UITableViewCellStyleDefault 
				 reuseIdentifier:SimpleTableIdentifier] autorelease]; 
		
		CGRect nameValueRect = CGRectMake(5,2, 50, 50); 
        UIImageView *nameValue = [[UIImageView alloc] initWithFrame:nameValueRect]; 
		//nameValue.backgroundColor=[UIColor clearColor];
        nameValue.tag = kname; 
        [cell.contentView addSubview:nameValue]; 
        
		
		
		CGRect colorValueRect = CGRectMake(60, 2, 250,50); 
		UILabel *colorValue = [[UILabel alloc] initWithFrame: colorValueRect]; 
        colorValue.tag = kdesc; 
        [cell.contentView addSubview:colorValue]; 
        
		
    } 
	NSUInteger row = [indexPath row]; 
	UIImageView *name = (UIImageView *)[cell.contentView viewWithTag: kname]; 
	/*
	NSString *imgStr=[[NSString alloc]initWithFormat:@"https://graph.facebook.com/%@/picture",[idList objectAtIndex:row]];
	NSLog(@"image Url :%@",imgStr);
	NSURL *url = [NSURL URLWithString:imgStr];
	
	NSData *urlData = [NSData dataWithContentsOfURL:url];*/
	
	UIImage *image = [UIImage imageWithData:[dataArray objectAtIndex:row]];
	name.image = image;
    UILabel *color = (UILabel *)[cell.contentView viewWithTag: kdesc]; 
	
    color.text = [list objectAtIndex:row]; 
	return cell;
    /*
	 NSUInteger row = [indexPath row]; 
	 cell.textLabel.text = [list objectAtIndex:row]; 
	 //cell.textColor=[UIColor whiteColor];
	 cell.accessoryType=UITableViewCellAccessoryDetailDisclosureButton;
	 return cell; 
	 */
} 


@end
