
#import <Foundation/Foundation.h>

@interface NSCharacterSet (NSCharacterSet_Extensions)

+ (NSCharacterSet *)linebreaksCharacterSet;

@end
