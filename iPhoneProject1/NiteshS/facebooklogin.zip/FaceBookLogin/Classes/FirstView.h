//
//  FirstView.h
//  FaceBookLogin
//
//  Created by ampheetech on 8/26/11.
//  Copyright 2011 ampheetech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainViewController.h"

@interface FirstView : UIViewController {
	MainViewController *mainView;
}
@property (nonatomic,retain)MainViewController *mainView;
-(IBAction)buttonPress:(id)sender;
@end
