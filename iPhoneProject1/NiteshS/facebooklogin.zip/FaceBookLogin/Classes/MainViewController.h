//
//  MainViewController.h
//  FaceBookLogin
//
//  Created by ampheetech on 8/26/11.
//  Copyright 2011 ampheetech. All rights reserved.
//

#import <UIKit/UIKit.h>

@class FirstView;
@interface MainViewController : UIViewController {
	IBOutlet UIWindow *mainWindow;
	FirstView *firstView;
}
@property (nonatomic,retain)UIWindow *mainWindow;
-(void)pressButton;
-(void)FirstViewCall;
@end
