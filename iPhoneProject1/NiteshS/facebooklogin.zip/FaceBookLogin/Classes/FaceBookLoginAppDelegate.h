//
//  FaceBookLoginAppDelegate.h
//  FaceBookLogin
//
//  Created by ampheetech on 8/26/11.
//  Copyright ampheetech 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FaceBookLoginAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
	IBOutlet UIViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

