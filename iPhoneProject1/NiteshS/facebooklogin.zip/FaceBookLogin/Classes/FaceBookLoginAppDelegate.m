//
//  FaceBookLoginAppDelegate.m
//  FaceBookLogin
//
//  Created by ampheetech on 8/26/11.
//  Copyright ampheetech 2011. All rights reserved.
//

#import "FaceBookLoginAppDelegate.h"

@implementation FaceBookLoginAppDelegate

@synthesize window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    

    // Override point for customization after application launch
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [window release];
    [super dealloc];
}


@end
