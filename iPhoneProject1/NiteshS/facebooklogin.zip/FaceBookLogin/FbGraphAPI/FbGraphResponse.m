



#import "FbGraphResponse.h"


@implementation FbGraphResponse

@synthesize htmlResponse;
@synthesize imageResponse;
@synthesize error;

-(void) dealloc {
	
	if (htmlResponse != nil) {
		[htmlResponse release];
	}
	
	if (imageResponse != nil) {
		[imageResponse release];
	}
	
	if (error != nil) {
		[error release];
	}
	
    [super dealloc];
}

@end
