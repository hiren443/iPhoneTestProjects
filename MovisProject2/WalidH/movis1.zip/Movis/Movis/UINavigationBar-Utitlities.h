//
//  UINavigationBar-Utitlities.h
//  CoreDataBooks
//
//  Created by Saad Mubarak on 5/3/10.
//  Copyright 2010 Beaconhouse National University. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>



@interface UINavigationBar (UINavigationBarCategory)

- (void)drawRect:(CGRect)rect;

@end
