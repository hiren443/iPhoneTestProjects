//
//  AppDelegate.h
//  Movis
//
//  Created by Imran Ishaq on 8/24/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#define kRootURL @"http://localhost"
#define kRootURL @"http://localhost"

#define kShowLog 1
#define kHasLoggedIn @ "kHasLoggedIn"
#define kIsLoadingFirstTime @ "kIsLoadingFirstTime"
#define kHasUserRemembered @"kHasUserRemembered"