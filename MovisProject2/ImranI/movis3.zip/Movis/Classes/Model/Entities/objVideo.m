//
//  objVideo.m
//  Movis
//
//  Created by Imran Ishaq on 8/26/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "objVideo.h"


@implementation objVideo
@synthesize strVideoName,strVideoPath,videoID,strimgName;
@end
