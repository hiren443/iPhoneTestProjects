//
//  Friends.m
//  View Friends
//
//  Created by Imran Ishaq on 8/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "Friends.h"


@implementation Friends

@synthesize frndID,strFriendName;
@end
